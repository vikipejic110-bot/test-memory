<?php
if (!defined('ABSPATH')) exit;

final class MGG_Wellness_Admin {
    public static function pending_count(): int {
        if (get_option('mgg_wellness_db_version') !== '1') return 0;
        global $wpdb;
        return (int) $wpdb->get_var('SELECT COUNT(*) FROM ' . MGG_Wellness::table('bookings') . " WHERE status = 'pending'");
    }

    public static function badge_assets(): void {
        if (!current_user_can('manage_options')) return;
        wp_enqueue_script('mgg-wellness-badge', plugins_url('assets/wellness-badge.js', MGG_FILE), [], MGG_VERSION, true);
        wp_localize_script('mgg-wellness-badge', 'mggWellnessBadge', [
            'url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mgg_wellness_count'),
            'label' => 'Wellness zahtjevi na čekanju: ',
        ]);
    }

    public static function badge_ajax(): void {
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Nemate dozvolu.'], 403);
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') wp_send_json_error(['message' => 'Metoda nije dozvoljena.'], 405);
        $nonce = is_string($_POST['nonce'] ?? null) ? $_POST['nonce'] : '';
        if (!wp_verify_nonce($nonce, 'mgg_wellness_count')) wp_send_json_error(['message' => 'Osvježite stranicu.'], 403);
        nocache_headers();
        wp_send_json_success(['count' => self::pending_count()]);
    }

    public static function assets(string $hook): void {
        if (!str_contains($hook, 'memory-guest-guide-wellness')) return;
        wp_enqueue_style('mgg-date-picker', plugins_url('assets/vendor/flatpickr.min.css', MGG_FILE), [], '4.6.13');
        wp_enqueue_style('mgg-date-format', plugins_url('assets/date-format.css', MGG_FILE), ['mgg-date-picker'], MGG_VERSION);
        wp_enqueue_script('mgg-date-picker', plugins_url('assets/vendor/flatpickr.min.js', MGG_FILE), [], '4.6.13', true);
        wp_enqueue_script('mgg-date-format', plugins_url('assets/date-format.js', MGG_FILE), ['mgg-date-picker'], MGG_VERSION, true);
    }

    public static function menu(): void {
        if (!current_user_can('manage_options')) return;
        $count = self::pending_count();
        $title = 'Wellness';
        if ($count) $title .= ' <span class="update-plugins count-' . $count . ' mgg-wellness-count" aria-live="polite" aria-label="Wellness zahtjevi na čekanju: ' . $count . '"><span class="plugin-count">' . $count . '</span></span>';
        add_submenu_page('memory-guest-guide', 'Wellness', $title, 'manage_options', 'memory-guest-guide-wellness', [self::class, 'page']);
    }

    private static function form(string $verb, int $id = 0): void {
        echo '<form ' . ($verb === 'cancel' ? 'data-mgg-confirm="Otkazati rezervaciju i osloboditi termin?" ' : '') . 'method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('mgg_wellness_admin_' . $verb . '_' . $id);
        echo '<input type="hidden" name="action" value="mgg_wellness_admin"><input type="hidden" name="verb" value="' . esc_attr($verb) . '"><input type="hidden" name="id" value="' . $id . '">';
    }

    private static function hours(string $name, int $value, bool $end = false): void {
        echo '<select name="' . esc_attr($name) . '">';
        for ($h = $end ? 1 : 0; $h <= ($end ? 24 : 23); $h++) echo '<option value="' . $h . '" ' . selected($value, $h, false) . '>' . MGG_Wellness::time_label($h) . '</option>';
        echo '</select>';
    }

    public static function action(): void {
        MGG_Admin::guard();
        $verb = is_string($_POST['verb'] ?? null) ? sanitize_key($_POST['verb']) : '';
        $id = absint($_POST['id'] ?? 0);
        check_admin_referer('mgg_wellness_admin_' . $verb . '_' . $id);
        try {
            if (in_array($verb, ['approve','reject','cancel'], true)) MGG_Wellness::decide($id, $verb);
            elseif ($verb === 'move') MGG_Wellness::move($id, MGG_Admin::clean($_POST['day'] ?? '', 10), $_POST['start'] ?? '', $_POST['end'] ?? '');
            elseif ($verb === 'availability') MGG_Wellness::availability(MGG_Admin::clean($_POST['day'] ?? '', 10), $_POST['start'] ?? '', $_POST['end'] ?? '', MGG_Admin::clean($_POST['availability'] ?? '', 10));
            elseif ($verb === 'settings') MGG_Wellness::save_config($_POST);
            else throw new InvalidArgumentException('Nepoznata radnja.');
        } catch (Throwable $e) {
            wp_die(esc_html($e instanceof MGG_Wellness_Error || $e instanceof InvalidArgumentException ? $e->getMessage() : 'Promjenu nije moguće sačuvati. Pokušajte ponovo.'), '', ['response' => $e instanceof MGG_Wellness_Error ? $e->getCode() : 400, 'back_link' => true]);
        }
        $args = ['saved' => 1];
        if (is_string($_POST['return_day'] ?? null) && preg_match('/\A\d{4}-\d{2}-\d{2}\z/', $_POST['return_day'])) $args['day'] = $_POST['return_day'];
        wp_safe_redirect(MGG_Admin::url('-wellness', $args)); exit;
    }

    public static function page(): void {
        MGG_Admin::guard();
        try {
            $config = MGG_Wellness::config();
            $day = MGG_Wellness::day(is_string($_GET['day'] ?? null) ? $_GET['day'] : wp_date('Y-m-d'))->format('Y-m-d');
            $schedule = MGG_Wellness::schedule($day);
        } catch (Throwable $e) { wp_die(esc_html($e->getMessage()), '', ['back_link' => true]); }
        global $wpdb;
        $table = MGG_Wellness::table('bookings');
        $pending = self::pending_count();
        $filter = isset($_GET['pending']) ? 'pending' : 'day';
        $page = max(1, absint($_GET['paged'] ?? 1)); $limit = 30;
        $where = $filter === 'pending' ? "status = 'pending'" : $wpdb->prepare('day = %s', $day);
        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE {$where}");
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE {$where} ORDER BY day, start_hour, id DESC LIMIT %d OFFSET %d", $limit, ($page - 1) * $limit)) ?: [];
        $statuses = MGG_Wellness::statuses();
        echo '<div class="wrap mgg-admin mgg-wellness-admin"><h1>Wellness – rezervacije</h1>';
        if (isset($_GET['saved'])) echo '<div class="notice notice-success"><p>Promjena je sačuvana.</p></div>';
        echo '<p>Jedan zajednički Wellness prostor za sve apartmane. Svaki sat može pripadati samo jednoj rezervaciji. Zahtjev na čekanju odmah blokira termin; odbijanje ili otkazivanje ga oslobađa.</p><p><a class="button" href="' . esc_url(MGG_Admin::url('-wellness', ['day' => $day])) . '">Pregled po danima</a> <a class="button" href="' . esc_url(MGG_Admin::url('-wellness', ['pending' => 1])) . '">Svi zahtjevi na čekanju (' . $pending . ')</a></p>';
        echo '<form method="get" class="mgg-wellness-filter"><input type="hidden" name="page" value="memory-guest-guide-wellness"><label>Datum <input name="day" type="date" value="' . esc_attr($day) . '" required></label> <button class="button">Prikaži dan</button></form><p>Vremenska zona: <strong>' . esc_html(wp_timezone_string()) . '</strong>. Podrazumijevani raspored: ' . MGG_Wellness::time_label((int) $config['open']) . '–' . MGG_Wellness::time_label((int) $config['close']) . '.</p>';
        if (!$config['enabled']) echo '<div class="notice notice-warning"><p>Novi Wellness zahtjevi su isključeni. Postojeće rezervacije su sačuvane.</p></div>';
        echo '<h2>Termini za ' . esc_html(MGG_Wellness::day($day)->format('j.n.Y')) . '</h2><div class="mgg-wellness-day">';
        foreach ($schedule['slots'] as $slot) echo '<span class="mgg-wellness-slot ' . esc_attr($slot['status']) . '"><strong>' . esc_html($slot['label']) . '</strong><br>' . esc_html($statuses[$slot['status']]) . '</span>';
        echo '</div><h2>' . ($filter === 'pending' ? 'Svi zahtjevi na čekanju' : 'Rezervacije za odabrani dan') . '</h2><table class="widefat striped"><thead><tr><th>Gost i apartman</th><th>Datum i termin</th><th>Status</th><th>Radnje</th></tr></thead><tbody>';
        foreach ($rows as $row) {
            $payload = MGG_Store::decrypt($row->payload);
            $guest = $payload === null ? [] : (json_decode($payload, true) ?: []);
            echo '<tr><td><strong>' . esc_html($guest['name'] ?? 'Podatke nije moguće otvoriti') . '</strong><br>' . esc_html($guest['apartment'] ?? '') . '<br><small>' . esc_html($guest['label'] ?? '') . ' · Zahtjev #' . (int) $row->id . '</small>';
            if (!empty($guest['note'])) echo '<p>' . nl2br(esc_html($guest['note'])) . '</p>';
            echo '</td><td>' . esc_html(MGG_Wellness::day($row->day)->format('j.n.Y')) . '<br>' . MGG_Wellness::time_label((int) $row->start_hour) . '–' . MGG_Wellness::time_label((int) $row->end_hour) . '<br><small>Poslano: ' . esc_html(MGG_Admin::date((int) $row->created_at)) . '</small></td><td>' . esc_html($statuses[$row->status] ?? $row->status) . '</td><td>';
            if ($row->status === 'pending') foreach (['approve' => 'Odobri', 'reject' => 'Odbij'] as $verb => $label) {
                self::form($verb, (int) $row->id);
                echo '<input type="hidden" name="return_day" value="' . esc_attr($day) . '"><button class="button ' . ($verb === 'approve' ? 'button-primary' : '') . '">' . $label . '</button></form>';
            }
            if (in_array($row->status, ['pending','confirmed'], true)) {
                self::form('cancel', (int) $row->id);
                echo '<input type="hidden" name="return_day" value="' . esc_attr($day) . '"><button class="button" data-mgg-confirm="Otkazati rezervaciju i osloboditi termin?">Otkaži rezervaciju</button></form><details><summary>Promijeni datum / termin</summary>';
                self::form('move', (int) $row->id);
                echo '<input type="hidden" name="return_day" value="' . esc_attr($day) . '"><p><label>Datum <input type="date" name="day" value="' . esc_attr($row->day) . '" required></label></p><p><label>Od '; self::hours('start', (int) $row->start_hour); echo '</label> <label>Do '; self::hours('end', (int) $row->end_hour, true); echo '</label></p><button class="button">Sačuvaj novi termin</button></form></details>';
            }
            echo '</td></tr>';
        }
        if (!$rows) echo '<tr><td colspan="4">Nema rezervacija u ovom pregledu.</td></tr>';
        echo '</tbody></table>';
        if ($total > $limit) echo '<p>' . wp_kses_post(paginate_links(['base' => add_query_arg('paged', '%#%', MGG_Admin::url('-wellness', $filter === 'pending' ? ['pending' => 1] : ['day' => $day])), 'format' => '', 'current' => $page, 'total' => (int) ceil($total / $limit)])) . '</p>';
        echo '<div class="mgg-wellness-admin-settings"><section class="mgg-panel"><h2>Dodaj, otvori ili blokiraj termine</h2><p>Izmjena važi samo za odabrani datum. Ponuđeni period se dijeli na jednosatne termine. Rezervisani sati ne mogu se prepisati ovom radnjom.</p>';
        self::form('availability');
        echo '<input type="hidden" name="return_day" value="' . esc_attr($day) . '"><p><label>Datum <input type="date" name="day" value="' . esc_attr($day) . '" required></label></p><p><label>Od '; self::hours('start', (int) $config['open']); echo '</label> <label>Do '; self::hours('end', (int) $config['close'], true); echo '</label></p><p><label>Radnja <select name="availability"><option value="open">Ponudi / oslobodi termine</option><option value="block">Blokiraj termine</option><option value="reset">Vrati podrazumijevani raspored</option></select></label></p><button class="button button-primary">Sačuvaj termine</button></form></section><section class="mgg-panel"><h2>Radno vrijeme i podešavanja</h2>';
        self::form('settings');
        echo '<p><label><input type="checkbox" name="enabled" value="1" ' . checked($config['enabled'], true, false) . '> Omogući gostima Wellness rezervacije</label></p><p><label>Otvaranje '; self::hours('open', (int) $config['open']); echo '</label> <label>Zatvaranje '; self::hours('close', (int) $config['close'], true); echo '</label></p><p><label>Koliko dana unaprijed <input type="number" name="days" min="1" max="90" value="' . (int) $config['days'] . '" required></label></p><p>08:00–22:00 znači termine od 08:00–09:00 do 21:00–22:00. Promjena rasporeda ne briše postojeće zahtjeve ni rezervacije; pojedinačno otvoreni/blokirani sati ostaju izuzeci dok ih ne vratite na podrazumijevani raspored.</p><button class="button button-primary">Sačuvaj Wellness podešavanja</button></form></section></div></div>';
    }
}
