<?php
if (!defined('ABSPATH')) exit;

final class MGG_Wellness_Error extends RuntimeException {
    public string $english;
    public function __construct(string $sr, string $en, int $status = 400) {
        parent::__construct($sr, $status); $this->english = $en;
    }
}

final class MGG_Wellness {
    public static function table(string $part): string {
        global $wpdb;
        return $wpdb->prefix . 'memory_wellness_' . $part;
    }

    public static function defaults(): array {
        return ['enabled' => true, 'open' => 8, 'close' => 22, 'days' => 30];
    }

    public static function upgrade(): void {
        if (get_option('mgg_wellness_db_version') === '1') return;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $bookings = self::table('bookings'); $claims = self::table('claims'); $state = self::table('state');
        dbDelta("CREATE TABLE {$bookings} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            guest_link_id bigint(20) unsigned NOT NULL,
            day date NOT NULL,
            start_hour tinyint unsigned NOT NULL,
            end_hour tinyint unsigned NOT NULL,
            status varchar(16) NOT NULL DEFAULT 'pending',
            request_key char(64) NOT NULL,
            payload longtext NOT NULL,
            created_at bigint(20) unsigned NOT NULL,
            updated_at bigint(20) unsigned NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY request_key (request_key),
            KEY guest_day (guest_link_id,day),
            KEY day_status (day,status)
        ) ENGINE=InnoDB {$charset};");
        dbDelta("CREATE TABLE {$claims} (
            day date NOT NULL,
            hour tinyint unsigned NOT NULL,
            booking_id bigint(20) unsigned NOT NULL DEFAULT 0,
            override_open smallint NOT NULL DEFAULT 0,
            PRIMARY KEY  (day,hour),
            KEY booking_id (booking_id)
        ) ENGINE=InnoDB {$charset};");
        dbDelta("CREATE TABLE {$state} (
            id tinyint unsigned NOT NULL,
            payload longtext NOT NULL,
            PRIMARY KEY  (id)
        ) ENGINE=InnoDB {$charset};");
        foreach ([$bookings, $claims, $state] as $table) {
            $row = $wpdb->get_row($wpdb->prepare('SHOW TABLE STATUS WHERE Name = %s', $table));
            if (!$row || strcasecmp($row->Engine, 'InnoDB') !== 0) return;
        }
        // Only new Wellness tables/options are initialized. Existing guide data is untouched.
        $ok = $wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$state} (id,payload) VALUES (1,%s)", wp_json_encode(self::defaults())));
        if ($ok !== false && $wpdb->get_var("SELECT id FROM {$state} WHERE id = 1")) update_option('mgg_wellness_db_version', '1', false);
    }

    private static function require(bool $condition, string $sr, string $en, int $code = 400): void {
        if (!$condition) throw new MGG_Wellness_Error($sr, $en, $code);
    }

    private static function sql($result): void {
        self::require($result !== false, 'Čuvanje nije uspjelo. Pokušajte ponovo.', 'Saving failed. Please try again.', 503);
    }

    public static function config(): array {
        global $wpdb;
        $raw = $wpdb->get_var('SELECT payload FROM ' . self::table('state') . ' WHERE id = 1');
        $value = is_string($raw) ? json_decode($raw, true) : null;
        self::require(is_array($value), 'Wellness trenutno nije dostupan. Obratite se domaćinu.', 'Wellness is temporarily unavailable. Please contact your host.', 503);
        return array_replace(self::defaults(), $value);
    }

    private static function atomic(callable $action) {
        global $wpdb;
        self::require(get_option('mgg_wellness_db_version') === '1', 'Wellness tabele nisu spremne.', 'Wellness storage is not ready.', 503);
        self::sql($wpdb->query('START TRANSACTION'));
        try {
            // All Wellness mutations lock the same durable InnoDB row. This serializes
            // booking, approval, rejection, moves, availability and schedule changes.
            $raw = $wpdb->get_var('SELECT payload FROM ' . self::table('state') . ' WHERE id = 1 FOR UPDATE');
            $config = is_string($raw) ? json_decode($raw, true) : null;
            self::require(is_array($config), 'Wellness trenutno nije dostupan.', 'Wellness is temporarily unavailable.', 503);
            $result = $action(array_replace(self::defaults(), $config));
            self::sql($wpdb->query('COMMIT'));
            return $result;
        } catch (Throwable $e) {
            $wpdb->query('ROLLBACK');
            throw $e;
        }
    }

    public static function day($raw): DateTimeImmutable {
        self::require(is_string($raw), 'Izaberite datum.', 'Choose a date.');
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $raw, wp_timezone());
        self::require($date && $date->format('Y-m-d') === $raw, 'Datum nije ispravan.', 'Invalid date.');
        return $date;
    }

    public static function hour($raw, bool $end = false): int {
        self::require((is_string($raw) || is_int($raw)) && preg_match('/\A\d{1,2}\z/', (string) $raw), 'Vrijeme nije ispravno.', 'Invalid time.');
        $value = (int) $raw;
        self::require($value >= 0 && $value <= ($end ? 24 : 23), 'Vrijeme nije ispravno.', 'Invalid time.');
        return $value;
    }

    public static function time_label(int $hour): string { return sprintf('%02d:00', $hour); }

    private static function period(DateTimeImmutable $day, int $hour): array {
        $start = $day->setTime($hour, 0);
        $end = $hour === 23 ? $day->modify('+1 day')->setTime(0, 0) : $day->setTime($hour + 1, 0);
        return [$start->getTimestamp(), $end->getTimestamp(), $start->format('H') === sprintf('%02d', $hour) && $end->getTimestamp() - $start->getTimestamp() === HOUR_IN_SECONDS];
    }

    public static function bounds(array $config, ?object $link = null): array {
        $today = new DateTimeImmutable('today', wp_timezone());
        $last = $today->modify('+' . (int) $config['days'] . ' days');
        if ($link && (int) $link->expires_at > 0) {
            $expires = (new DateTimeImmutable('@' . (int) $link->expires_at))->setTimezone(wp_timezone());
            if ($expires < $last) $last = $expires;
        }
        return [$today->format('Y-m-d'), $last->format('Y-m-d')];
    }

    private static function date_allowed(DateTimeImmutable $day, array $config, ?object $link = null): void {
        [$first, $last] = self::bounds($config, $link);
        $date = $day->format('Y-m-d');
        self::require($date >= $first && $date <= $last, 'Izaberite datum u dozvoljenom periodu.', 'Choose a date within the available period.');
    }

    private static function claim(string $day, int $hour): object {
        global $wpdb; $table = self::table('claims');
        self::sql($wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$table} (day,hour) VALUES (%s,%d)", $day, $hour)));
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE day = %s AND hour = %d FOR UPDATE", $day, $hour));
        self::require((bool) $row, 'Termin nije moguće provjeriti.', 'The time slot could not be checked.', 503);
        return $row;
    }

    private static function reserve(DateTimeImmutable $date, int $start, int $end, array $config, int $booking_id, ?object $link = null): void {
        global $wpdb;
        self::require($end > $start, 'Završetak mora biti poslije početka.', 'The end time must be after the start time.');
        $day = $date->format('Y-m-d');
        for ($hour = $start; $hour < $end; $hour++) {
            [$from, $to, $valid] = self::period($date, $hour);
            self::require($valid && $from > time(), 'Termin je prošao ili nije dostupan.', 'This time slot is in the past or unavailable.');
            if ($link) self::require($to <= (int) $link->expires_at, 'Termin je poslije isteka vašeg linka.', 'This time slot is after your guide link expires.');
            $row = self::claim($day, $hour);
            $offered = (int) $row->override_open === 1 || ($hour >= (int) $config['open'] && $hour < (int) $config['close']);
            self::require($offered && (int) $row->override_open !== -1 && ((int) $row->booking_id === 0 || (int) $row->booking_id === $booking_id), 'Jedan od odabranih termina više nije slobodan. Osvježite pregled.', 'One of the selected time slots is no longer available. Refresh the schedule.', 409);
            self::sql($wpdb->update(self::table('claims'), ['booking_id' => $booking_id], ['day' => $day, 'hour' => $hour], ['%d'], ['%s','%d']));
        }
    }

    public static function request(object $link, array $input): int {
        return self::atomic(static function ($config) use ($link, $input) {
            global $wpdb;
            $fresh = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . MGG_Store::table() . ' WHERE id = %d FOR UPDATE', $link->id));
            self::require($fresh && MGG_Store::active($fresh) && ($fresh->kind ?? 'reservation') === 'reservation', 'Link više nije aktivan.', 'Your guide link is no longer active.', 410);
            self::require((bool) $config['enabled'], 'Wellness rezervacije trenutno su zatvorene.', 'Wellness reservations are currently closed.', 409);
            $key = $input['request_id'] ?? '';
            self::require(is_string($key) && preg_match('/\A[a-f0-9]{32}\z/', $key), 'Zahtjev nije ispravan. Osvježite stranicu.', 'Invalid request. Refresh the page.');
            $key = hash('sha256', $fresh->id . '|' . $key);
            $old = $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . self::table('bookings') . ' WHERE request_key = %s', $key));
            if ($old) return (int) $old;
            $day = self::day($input['day'] ?? ''); self::date_allowed($day, $config, $fresh);
            $start = self::hour($input['start'] ?? ''); $end = self::hour($input['end'] ?? '', true);
            $name = MGG_Admin::clean($input['name'] ?? '', 120);
            self::require($name !== '', 'Unesite ime i prezime.', 'Enter your full name.');
            $note = MGG_Admin::clean($input['note'] ?? '', 1000, true);
            $guest = MGG_Store::payload($fresh);
            $apartment_id = MGG_Apartments::resolve($guest);
            $payload = ['name' => $name, 'note' => $note, 'apartment' => $guest['apartment'] ?: MGG_Apartments::label($apartment_id), 'label' => $guest['label'] ?? ''];
            self::sql($wpdb->insert(self::table('bookings'), ['guest_link_id' => $fresh->id, 'day' => $day->format('Y-m-d'), 'start_hour' => $start, 'end_hour' => $end, 'status' => 'pending', 'request_key' => $key, 'payload' => MGG_Store::encrypt(wp_json_encode($payload, JSON_UNESCAPED_UNICODE)), 'created_at' => time(), 'updated_at' => time()], ['%d','%s','%d','%d','%s','%s','%s','%d','%d']));
            $id = (int) $wpdb->insert_id;
            self::reserve($day, $start, $end, $config, $id, $fresh);
            return $id;
        });
    }

    public static function decide(int $id, string $verb): void {
        self::atomic(static function ($config) use ($id, $verb) {
            global $wpdb; $table = self::table('bookings');
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d FOR UPDATE", $id));
            self::require((bool) $row, 'Rezervacija ne postoji.', 'Reservation not found.', 404);
            $next = ['approve' => 'confirmed', 'reject' => 'rejected', 'cancel' => 'cancelled'][$verb] ?? '';
            self::require($next !== '', 'Nepoznata radnja.', 'Unknown action.');
            if ($row->status === $next) return;
            self::require(($verb === 'approve' || $verb === 'reject') ? $row->status === 'pending' : in_array($row->status, ['pending','confirmed'], true), 'Status rezervacije je već promijenjen. Osvježite pregled.', 'Reservation status has already changed. Refresh the page.', 409);
            if ($verb === 'approve') {
                [$from] = self::period(self::day($row->day), (int) $row->start_hour);
                self::require($from > time(), 'Termin je već počeo ili prošao. Odbijte zahtjev.', 'This time slot has already started or passed. Reject the request.', 409);
                $count = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . self::table('claims') . ' WHERE booking_id = %d', $id));
                self::require($count === (int) $row->end_hour - (int) $row->start_hour, 'Zaključavanje termina nije potpuno. Kontaktirajte podršku.', 'The time slot lock is incomplete. Contact support.', 409);
            } else self::sql($wpdb->update(self::table('claims'), ['booking_id' => 0], ['booking_id' => $id], ['%d'], ['%d']));
            self::sql($wpdb->update($table, ['status' => $next, 'updated_at' => time()], ['id' => $id], ['%s','%d'], ['%d']));
        });
    }

    public static function move(int $id, string $raw_day, $raw_start, $raw_end): void {
        self::atomic(static function ($config) use ($id, $raw_day, $raw_start, $raw_end) {
            global $wpdb; $table = self::table('bookings');
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d FOR UPDATE", $id));
            self::require($row && in_array($row->status, ['pending','confirmed'], true), 'Moguće je mijenjati samo rezervacije na čekanju ili potvrđene rezervacije.', 'Only pending or confirmed reservations can be changed.', 409);
            $day = self::day($raw_day); $start = self::hour($raw_start); $end = self::hour($raw_end, true);
            self::date_allowed($day, $config);
            self::sql($wpdb->update(self::table('claims'), ['booking_id' => 0], ['booking_id' => $id], ['%d'], ['%d']));
            self::reserve($day, $start, $end, $config, $id);
            self::sql($wpdb->update($table, ['day' => $day->format('Y-m-d'), 'start_hour' => $start, 'end_hour' => $end, 'updated_at' => time()], ['id' => $id], ['%s','%d','%d','%d'], ['%d']));
        });
    }

    public static function availability(string $raw_day, $raw_start, $raw_end, string $verb): void {
        self::atomic(static function ($config) use ($raw_day, $raw_start, $raw_end, $verb) {
            global $wpdb;
            $day = self::day($raw_day); $start = self::hour($raw_start); $end = self::hour($raw_end, true);
            self::date_allowed($day, array_replace($config, ['days' => 365]));
            self::require($end > $start && in_array($verb, ['open','block','reset'], true), 'Izaberite ispravan period i radnju.', 'Choose a valid period and action.');
            foreach (range($start, $end - 1) as $hour) {
                $row = self::claim($day->format('Y-m-d'), $hour);
                self::require((int) $row->booking_id === 0, 'Period sadrži rezervisan termin. Prvo odbijte, otkažite ili premjestite rezervaciju.', 'The period contains a booked slot. Reject, cancel or move the reservation first.', 409);
                self::sql($wpdb->update(self::table('claims'), ['override_open' => ['open' => 1, 'block' => -1, 'reset' => 0][$verb]], ['day' => $day->format('Y-m-d'), 'hour' => $hour], ['%d'], ['%s','%d']));
            }
        });
    }

    public static function save_config(array $input): void {
        self::atomic(static function ($old) use ($input) {
            global $wpdb;
            $open = self::hour($input['open'] ?? ''); $close = self::hour($input['close'] ?? '', true);
            $days = filter_var($input['days'] ?? null, FILTER_VALIDATE_INT);
            self::require($close > $open && $days !== false && $days >= 1 && $days <= 90, 'Provjerite radno vrijeme i period od 1 do 90 dana.', 'Check the opening hours and a booking period of 1 to 90 days.');
            $new = array_replace($old, ['enabled' => !empty($input['enabled']), 'open' => $open, 'close' => $close, 'days' => $days]);
            self::sql($wpdb->update(self::table('state'), ['payload' => wp_json_encode($new)], ['id' => 1], ['%s'], ['%d']));
        });
    }

    public static function statuses(bool $en = false): array {
        return $en ? ['free' => 'Available', 'pending' => 'Pending approval', 'confirmed' => 'Reserved', 'blocked' => 'Unavailable', 'past' => 'Past', 'rejected' => 'Declined', 'cancelled' => 'Cancelled']
            : ['free' => 'Slobodno', 'pending' => 'Na čekanju', 'confirmed' => 'Rezervisano', 'blocked' => 'Nedostupno', 'past' => 'Prošao', 'rejected' => 'Odbijeno', 'cancelled' => 'Otkazano'];
    }

    public static function schedule(string $raw_day, ?object $link = null): array {
        global $wpdb;
        $config = self::config(); $date = self::day($raw_day);
        if ($link) self::date_allowed($date, $config, $link);
        $claims = self::table('claims'); $bookings = self::table('bookings');
        $rows = $wpdb->get_results($wpdb->prepare("SELECT c.*, b.status, b.guest_link_id FROM {$claims} c LEFT JOIN {$bookings} b ON b.id = c.booking_id WHERE c.day = %s", $raw_day));
        $by_hour = []; foreach ($rows ?: [] as $row) $by_hour[(int) $row->hour] = $row;
        $slots = [];
        for ($hour = 0; $hour < 24; $hour++) {
            $row = $by_hour[$hour] ?? null;
            $normal = $hour >= (int) $config['open'] && $hour < (int) $config['close'];
            if (!$normal && !$row) continue;
            if (!$normal && $row && !(int) $row->override_open && !(int) $row->booking_id) continue;
            [$from, $to, $valid] = self::period($date, $hour);
            $status = 'free';
            if ($row && (int) $row->booking_id) $status = in_array($row->status, ['pending','confirmed'], true) ? $row->status : 'blocked';
            elseif (!$valid || $from <= time() || ($link && $to > (int) $link->expires_at)) $status = 'past';
            elseif (!$config['enabled'] || ($row && (int) $row->override_open === -1) || (!$normal && (!$row || (int) $row->override_open !== 1))) $status = 'blocked';
            $slots[] = ['hour' => $hour, 'label' => self::time_label($hour) . '–' . self::time_label($hour + 1), 'status' => $status, 'mine' => $link && $row && (int) $row->guest_link_id === (int) $link->id];
        }
        $mine = [];
        if ($link) {
            $mine = $wpdb->get_results($wpdb->prepare("SELECT id,day,start_hour,end_hour,status FROM {$bookings} WHERE guest_link_id = %d AND day = %s ORDER BY id DESC LIMIT 20", $link->id, $raw_day), ARRAY_A) ?: [];
        }
        [$min, $max] = self::bounds($config, $link);
        return ['enabled' => (bool) $config['enabled'], 'day' => $raw_day, 'min' => $min, 'max' => $max, 'timezone' => wp_timezone_string(), 'slots' => $slots, 'mine' => $mine];
    }

    public static function api(object $link, string $lang, string $action): void {
        $en = $lang === 'en';
        try {
            self::require(($link->kind ?? 'reservation') === 'reservation', 'Wellness rezervacija dostupna je preko ličnog linka rezervacije.', 'Use your personal reservation link to book Wellness.', 403);
            if ($action === 'slots') {
                self::require(($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST', 'Metoda nije dozvoljena.', 'Method not allowed.', 405);
                $result = self::schedule(is_string($_GET['mgg_day'] ?? null) ? $_GET['mgg_day'] : wp_date('Y-m-d'), $link);
            } elseif ($action === 'request') {
                self::require(($_SERVER['REQUEST_METHOD'] ?? '') === 'POST', 'Zahtjev se šalje kroz obrazac.', 'Submit requests using the form.', 405);
                $nonce = is_string($_POST['nonce'] ?? null) ? $_POST['nonce'] : '';
                self::require((bool) wp_verify_nonce($nonce, 'mgg_wellness_' . $link->id), 'Obrazac je istekao. Osvježite stranicu.', 'This form has expired. Refresh the page.', 403);
                $input = [];
                foreach (['day','start','end','name','note'] as $field) $input[$field] = $_POST['wellness_' . $field] ?? '';
                $input['request_id'] = $_POST['request_id'] ?? '';
                $id = self::request($link, $input);
                global $wpdb;
                $status = $wpdb->get_var($wpdb->prepare('SELECT status FROM ' . self::table('bookings') . ' WHERE id = %d', $id));
                $result = ['id' => $id, 'status' => $status, 'schedule' => self::schedule($input['day'], $link)];
            } else throw new MGG_Wellness_Error('Nepoznata radnja.', 'Unknown action.', 400);
            if (($_SERVER['REQUEST_METHOD'] ?? '') === 'HEAD') { header('Content-Type: application/json; charset=UTF-8'); exit; }
            wp_send_json(['ok' => true, 'data' => $result]);
        } catch (Throwable $e) {
            $message = $e instanceof MGG_Wellness_Error ? ($en ? $e->english : $e->getMessage()) : ($en ? 'The request could not be processed. Please try again.' : 'Zahtjev nije moguće obraditi. Pokušajte ponovo.');
            $status = $e instanceof MGG_Wellness_Error ? $e->getCode() : 503;
            wp_send_json(['ok' => false, 'message' => $message], $status);
        }
    }

    public static function card(object $link, string $lang, array $guest = []): void {
        if (($link->kind ?? 'reservation') !== 'reservation') return;
        try { $config = self::config(); } catch (Throwable $e) { return; }
        if (!$config['enabled']) return;
        if (!$guest) {
            try { $guest = MGG_Store::payload($link); } catch (Throwable $e) { $guest = []; }
        }
        $name = is_string($guest['label'] ?? null) ? sanitize_text_field($guest['label']) : '';
        $name = function_exists('mb_substr') ? mb_substr($name, 0, 120, 'UTF-8') : wp_check_invalid_utf8(substr($name, 0, 120), true);
        $en = $lang === 'en'; [$min, $max] = self::bounds($config, $link);
        $labels = $en ? [
            'load' => 'Loading available times…', 'choose' => 'Choose a start and end time.', 'send' => 'Send request', 'sending' => 'Sending…',
            'sent' => 'Your request was sent. The selected time is held until your host approves or declines it.', 'error' => 'Unable to load the schedule. Please try again.',
            'mine' => 'Your requests for this date', 'empty' => 'No time slots are offered for this date.', 'closed' => 'Wellness reservations are currently closed.', 'expired' => 'Your link has expired. Refresh the page or contact your host.',
        ] : [
            'load' => 'Učitavanje slobodnih termina…', 'choose' => 'Izaberite početak i završetak.', 'send' => 'Pošalji zahtjev', 'sending' => 'Slanje…',
            'sent' => 'Zahtjev je poslan. Termin je blokiran dok domaćin ne odobri ili odbije rezervaciju.', 'error' => 'Pregled termina nije moguće učitati. Pokušajte ponovo.',
            'mine' => 'Vaši zahtjevi za ovaj datum', 'empty' => 'Za ovaj datum nema ponuđenih termina.', 'closed' => 'Wellness rezervacije trenutno su zatvorene.', 'expired' => 'Vaš link je istekao. Osvježite stranicu ili kontaktirajte domaćina.',
        ];
        $labels['statuses'] = self::statuses($en);
        $url = MGG_Store::url($link, $lang);
        echo '<section class="mgg-step mgg-wellness" id="mgg-wellness" data-slots="' . esc_url(add_query_arg('mgg_wellness', 'slots', $url)) . '" data-request="' . esc_url(add_query_arg('mgg_wellness', 'request', $url)) . '" data-labels="' . esc_attr(wp_json_encode($labels)) . '"><details><summary><span>Wellness</span><strong>' . ($en ? 'Book Wellness' : 'Rezerviši Wellness') . '</strong></summary><div class="mgg-wellness-content"><p>' . ($en ? 'Choose a date and consecutive hourly slots. Requests require your host’s approval.' : 'Izaberite datum i jedan ili više uzastopnih jednosatnih termina. Rezervaciju potvrđuje domaćin.') . '</p>';
        echo '<p class="mgg-wellness-zone">' . ($en ? 'Local time: ' : 'Lokalno vrijeme: ') . esc_html(wp_timezone_string()) . '</p><form id="mgg-wellness-form"><label>' . ($en ? 'Date' : 'Datum') . '<input type="date" name="wellness_day" min="' . esc_attr($min) . '" max="' . esc_attr($max) . '" value="' . esc_attr($min) . '" required></label><div class="mgg-wellness-slots" aria-live="polite"></div><div class="mgg-wellness-range"><label>' . ($en ? 'From' : 'Od') . '<select name="wellness_start" required></select></label><label>' . ($en ? 'Until' : 'Do') . '<select name="wellness_end" required></select></label></div><label>' . ($en ? 'Full name' : 'Ime i prezime') . '<input name="wellness_name" autocomplete="name" maxlength="120" value="' . esc_attr($name) . '" required></label><label>' . ($en ? 'Note (optional)' : 'Napomena (opciono)') . '<textarea name="wellness_note" maxlength="1000" rows="2"></textarea></label><input type="hidden" name="nonce" value="' . esc_attr(wp_create_nonce('mgg_wellness_' . $link->id)) . '"><button class="mgg-button" type="submit" disabled>' . esc_html($labels['send']) . '</button><p class="mgg-wellness-feedback" role="status" aria-live="polite"></p></form><div class="mgg-wellness-mine" aria-live="polite"></div></div></details></section>';
    }
}
