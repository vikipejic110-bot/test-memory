=== Memory – uputstva za goste ===
Contributors: memory-residence
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 1.2.3
License: GPLv2 or later

Privatno SR/EN uputstvo za dolazak, sa zasebnim vremenski ograničenim linkom za svaku rezervaciju.

== Instalacija ==
1. WordPress → Dodaci → Dodaj novi → Otpremi dodatak.
2. Izaberite Memory-Wellness-1.2.3.zip, instalirajte i aktivirajte. Za nadogradnju izaberite zamjenu postojeće verzije, bez prethodnog brisanja.
3. Otvorite Uputstva za goste → Zajedničko uputstvo.
4. Jednom unesite Wi-Fi lozinku i provjerite telefon, vrijeme prijave/odjave i fotografije.
5. U SpeedyCache / CDN podešavanjima obavezno izuzmite /uputstvo-za-dolazak/* i zahtjeve sa parametrom memory_guest_guide. Zatim očistite postojeći keš.

Predložak i tri fotografije već su pripremljeni prema dostavljenom PDF-u.
Srpski tekst je latinicom i ijekavicom; postoji i nezavisni engleski tekst.
Stari SmartPierre link i Wi-Fi lozinka iz PDF-a nisu ugrađeni u distributivni paket.
Dodatak ne obrađuje automatski proizvoljne PDF datoteke. Uputstvo se uređuje kroz obrazac za tekst i izbor fotografija.

== Nova rezervacija ==
1. U aplikaciji SmartPierre kreirajte odgovarajući digitalni ključ i podesite njegovo važenje.
2. U WordPressu otvorite Uputstva za goste → Novi link.
3. Izaberite apartman iz padajuće liste i zalijepite SmartPierre link. Po želji unesite internu oznaku, tekstualni broj/naziv apartmana i posebnu fotografiju vrata.
4. Izaberite trajanje (podrazumijevano 30 dana) i kliknite Kreiraj link za gosta.
5. Kopirajte link ili gotovu poruku na srpskom/engleskom i pošaljite je gostu svojim uobičajenim kanalom.

Svako kreiranje pravi nezavisan link. Gost može otvarati isti link više puta do isteka.
Nisu potrebni nalog gosta, lozinka za WordPress niti novo pravljenje PDF-a.
Oznaka rezervacije koristi se kao prijedlog imena u gostovom Wellness obrascu; gost može izmijeniti taj unos samo za svoj Wellness zahtjev.
Izmjene zajedničkog uputstva vide se i na već kreiranim aktivnim linkovima.

== Upravljanje ==
Uredi: promjena SmartPierre linka, naziva apartmana, fotografije ili datuma isteka; adresa uputstva ostaje ista.
Poništi link: trenutno zatvara pristup tom uputstvu. Uređivanje poništenog zapisa ga ne aktivira ponovo.
Obriši zapis: trajno uklanja zapis i njegov link.
Poruka SR / Message EN: kopira pripremljenu poruku. Dodatak ne šalje email, SMS ni WhatsApp poruke.

== Nadogradnja sa 1.0.0 ==
Otpremite ZIP kroz Dodaci → Dodaj novi → Otpremi dodatak i izaberite zamjenu postojeće verzije.
Folder i glavni fajl ostaju memory-guest-guide/memory-guest-guide.php.
Ne brišite postojeći dodatak i ne mijenjajte WordPress salts.
Migracija se izvršava i kada se fajlovi zamijene dok je dodatak aktivan.
Postojeća tabela linkova samo dobija dodatne kolone; dodaje se odvojena tabela obavještenja.
Postojeći tokeni, adrese, datumi isteka, statusi, Wi-Fi i uređeni tekstovi ne mijenjaju se migracijom.
Ranije odštampani QR kodovi i poslati linkovi nastavljaju da rade.
Nakon zamjene očistite SpeedyCache/CDN keš. Ranije izuzetke za privatne vodiče ostavite aktivne.

== Apartmani ==
Uputstva za goste → Apartmani automatski prikazuje objavljeni WordPress sadržaj tipa rooms.
Izvorni apartmani se ne kopiraju. Promjena njihovog naziva na sajtu vidi se i u ovom spisku.
Ako nema odgovarajućeg sadržaja, opcija Dodaj ručno kreira privatni zapis samo za vodič.
Uredi uputstvo omogućava posebne Wi-Fi podatke, kontakt, fotografije i tekstove na oba jezika, uz dodatne informacije o apartmanu.
Prazna polja nasljeđuju zajedničko uputstvo; izvorni naziv/opis apartmana na sajtu se ne mijenja.
Stari linkovi se povezuju s apartmanom kada se njihov tekstualni naziv može jednoznačno prepoznati.
Za raniji unos koji sadrži samo nepoznat broj ili nejasan naziv otvorite Uredi rezervaciju i izaberite apartman. Adresa rezervacijskog linka ostaje ista.
Ako se apartman više ne objavljuje, njegova obavještenja se ne prikazuju drugim apartmanima.

== Stalni link i QR ==
U odjeljku Apartmani kliknite Kreiraj stalni link / QR. Link ostaje isti dok ga administrator izričito ne poništi.
QR kod generiše se lokalno u pregledniku administratora i preuzima kao PNG; link se ne šalje spoljnim QR servisima.
Stalni apartmanski vodič sadrži zajedničke/apartmanske informacije i obavještenja, ali nikada SmartPierre ključ pojedinačne rezervacije.
Za digitalni ključ gost i dalje dobija poseban vremenski ograničen link rezervacije.
QR se može preuzeti i za postojeće rezervacijske linkove; njihov prvobitni datum isteka i dalje važi.
Poništavanje stalnog linka je izričita administratorska radnja; raniji QR tog linka tada prestaje da radi.

== Obavještenja ==
Uputstva za goste → Obavještenja → Novo obavještenje.
Unesite naslov, tekst i opcioni http/https URL. Izaberite apartman ili Svi apartmani.
Mogući su zasebni engleski naslov/tekst; prazni engleski unosi koriste osnovni tekst.
Podesite status i datume prikazivanja prema WordPress vremenskoj zoni.
Prazan početak znači odmah; prazan završetak znači bez roka. Završetak isključuje prikaz od tog trenutka.
Zakazana, istekla i deaktivirana obavještenja ne prikazuju se gostima.
Ponovno otvaranje postojećeg vodiča odmah prikazuje važeće izmjene. Već otvorena stranica provjerava obavještenja svakih 20 sekundi i pri povratku na karticu.
Nisu potrebni novi rezervacijski linkovi ni novi QR kodovi nakon uređivanja obavještenja.

== Logo i prijava / odjava ==
Zajedničko uputstvo → Logo objekta: izaberite ili učitajte logo.
Logo je proporcionalan i centralno postavljen na početku vodiča; bez izbora koristi se WordPress custom_logo, ako postoji, ili naziv objekta.
Fotografija parkinga pripada zasebnom koraku uputstva, a ne cover dijelu.
Podrazumijevana vremena su CHECK-IN od 14:00 i CHECK-OUT do 10:00; oba su promjenjiva kroz postavke.
Ranije sačuvana druga vremena se nadogradnjom ne prepisuju.

== Važenje digitalnog ključa ==
Istek / poništavanje linka za uputstvo NE poništava digitalni ključ u SmartPierre sistemu.
Gost koji je već otvorio ili sačuvao originalni Pierre link može ga koristiti dok taj ključ važi kod provajdera.
Za stvarno zatvaranje pristupa podesite ili poništite ključ i u aplikaciji SmartPierre.
Dodatak ne otvara vrata niti poziva SmartPierre API. Nakon provjere važećeg linka, dugme vodi na zalijepljeni SmartPierre link.

== Privatnost i održavanje ==
Pristupni link sadrži nasumični 256-bitni token. Ko posjeduje taj link može vidjeti uputstvo do isteka; šaljite ga samo odgovarajućem gostu.
Guest stranice imaju no-store/noindex/no-referrer zaglavlja i ne sadrže skripte teme, analitiku ili spoljne fontove.
Pristup se provjerava na svakom otvaranju i ponovo pri kliku na digitalni ključ. Istek ne zavisi od WP-Cron-a.
Wi-Fi lozinka, SmartPierre link i podaci rezervacije čuvaju se šifrovano u WordPress bazi.
Šifrovanje koristi WordPress sigurnosne ključeve/salts i PHP OpenSSL AES-256-GCM.
Pri migraciji sačuvajte iste WordPress salts i rezervnu kopiju baze. Promjena salts onemogućava otvaranje starih šifrovanih podataka; tada napravite nove zapise i ponovo unesite postavke.
Fotografije iz biblioteke medija i ugrađene fotografije nisu tajne datoteke. Ne stavljajte lozinke ili pristupne kodove u slike.
Vrijeme se prikazuje prema vremenskoj zoni podešenoj u WordPressu.
Deaktivacija ne briše podatke. Uklanjanje dodatka čuva zapise, osim ako administrator izričito postavi MGG_DELETE_DATA na true u wp-config.php.

== Wellness – rezervacije (1.2.0) ==
Nadogradnja dodaje karticu Uputstva za goste → Wellness u isti dodatak.
Postojeće tabele, šifrovana podešavanja, sadržaj apartmana, obavještenja, tokeni,
datumi isteka, linkovi i QR kodovi ne mijenjaju se ovom nadogradnjom.
Wellness koristi tri zasebne nove InnoDB tabele i zasebnu verziju svoje šeme.
Instalacija i ponovljena inicijalizacija ne prepisuju ranije Wellness rezervacije.

Gost otvara svoj važeći rezervacijski link i odjeljak Wellness → Rezerviši Wellness.
Može odabrati datum, početak i kraj jednog ili više uzastopnih jednosatnih termina,
unijeti ime i prezime i poslati zahtjev. Napomena je opciona.
Slobodni, zauzeti, blokirani i termini na čekanju imaju zasebne tekstualne oznake.
Gost vidi svoje zahtjeve i njihove statuse, bez imena i podataka drugih gostiju.
Pregled otvorenog odjeljka automatski se osvježava svakih 15 sekundi; server uvijek
ponovo provjerava dostupnost pri slanju, čak i kada gost gleda stariji pregled.

Podrazumijevano radno vrijeme je 08:00–22:00: prvi termin je 08:00–09:00,
a posljednji 21:00–22:00. Za termin 22:00–23:00 postavite zatvaranje na 23:00.
U panelu je moguće mijenjati radno vrijeme, period rezervisanja (1–90 dana,
podrazumijevano 30), isključiti nove zahtjeve, nuditi dodatne sate za pojedini dan,
blokirati sate ili vratiti dan na podrazumijevani raspored.
Promjena radnog vremena ne briše postojeće rezervacije; one ostaju vidljive i
blokirane čak i ako su izvan novog radnog vremena. Pojedinačni izuzeci ostaju
aktivni dok ih administrator ne vrati na podrazumijevani raspored.

Jedan zajednički Wellness prostor koristi se za sve apartmane. Podnesen zahtjev dobija status
Na čekanju i odmah zaključava sve odabrane sate. Odobravanje daje status
Rezervisano; odbijanje ili otkazivanje oslobađa sate. Neuspjelo premještanje u
zauzet termin ne mijenja prvobitnu rezervaciju. Višesatni zahtjevi se čuvaju u
cjelini ili se potpuno odbijaju; nema djelimičnog rezervisanja.
Zahtjevi na čekanju se ne oslobađaju automatski dok administrator ne odluči.
Istek, poništavanje ili brisanje gostovog linka ne otkazuje ranije odobrenu ili
podnesenu Wellness rezervaciju. Administrator po potrebi otkazuje takvu rezervaciju u Wellnessu.

Milan koristi svoj WordPress nalog sa ovlašćenjem manage_options, isto kao za
postojeći panel dodatka. Pregled po danima i Svi zahtjevi na čekanju prikazuju
gosta, apartman, internu oznaku rezervacije, datum, sate i napomenu.
Odobri/Odbij dostupni su za zahtjeve na čekanju; otkazivanje i promjena termina
dostupni su za zahtjeve na čekanju i potvrđene rezervacije. Istorija se čuva.
Zahtjevi se prikazuju u panelu; email/SMS/WhatsApp poruke ne šalju se automatski.

Samo važeći lični rezervacijski link omogućava podnošenje zahtjeva. Stalni
apartmanski QR bez ličnog ključa ne omogućava Wellness rezervacije.
Ponovno slanje istog zahtjeva koristi idempotentni identifikator i ne pravi
duplu rezervaciju. Zaštita od preklapanja izvršava se kroz InnoDB transakciju,
zaključavanje kontrolnog reda i jedinstveni ključ datum/sat, a ne samo u prikazu.
Potrebna je InnoDB podrška i pravo kreiranja novih tabela. Ako inicijalizacija
Wellnessa ne uspije, slanje zahtjeva nije dozvoljeno; postojeći vodič ostaje dostupan.

Datumi i sati koriste WordPress vremensku zonu. Gost može rezervisati samo
buduće sate unutar podešenog perioda i prije isteka ličnog linka.
Ovo nije integracija sa datumima boravka iz WebBookingPro: taj podatak nije dio
postojećeg modela ličnih linkova. Nema izmjena rezervacija smještaja.
Nevažeći ili dvosmisleni jednosatni intervali pri promjeni ljetnjeg/zimskog
računanja vremena nisu ponuđeni kao slobodni termini.

== Changelog ==
= 1.2.3 =
Naziv usluge u cijelom interfejsu usklađen je na Wellness, uključujući gostov
naslov „Rezerviši Wellness“ / „Book Wellness“, administratorske poruke i oznaku
zahtjeva na čekanju. Izmijenjen je isključivo tekst; podaci, postojeći linkovi,
rezervacije i način rada ostaju isti. Nema migracije podataka.

= 1.2.2 =
Wellness meni dobija broj zahtjeva na čekanju; broj se osvježava svakih 15 sekundi
na administratorskim stranicama i pri povratku u prozor. Klik vodi na sve zahtjeve
na čekanju. Poslije odluke broj se smanjuje; kada nema zahtjeva, oznaka nestaje.
Ime u gostovom obrascu predlaže se iz postojeće oznake rezervacije, uz mogućnost
izmjene. Izmijenjeno ime važi samo za Wellness zahtjev i ne prepisuje izvorni zapis.
Prazna oznaka ostavlja polje prazno. Nema nove šeme niti migracije podataka.

= 1.2.1 =
Wellness datumi kod gosta i u administratorskim obrascima prikazuju se kao 7.11.2026,
nezavisno od jezika preglednika. Kalendar je lokalno uključen, bez spoljnih CDN poziva.
Srpski kalendar koristi latinicu. Datum koji se šalje serveru ostaje Y-m-d.
Nema migracije ni prepisivanja baze, vremenske zone, linkova ili rezervacija.

= 1.2.0 =
Integrisani Wellness panel i privatni gostov obrazac za Wellness rezervaciju.
Transakcijska zaštita od duplih i djelimičnih rezervacija, statusi i istorija.
Promjenjivo radno vrijeme, dnevni izuzeci, blokiranje i premještanje termina.
Odvojena aditivna migracija bez izmjene ranijih tabela i podataka vodiča.

= 1.1.1 =
Logo je jedina oznaka objekta na početku vodiča. Uklonjen ponovljeni naziv iz zaglavlja,
a pozdrav skraćen na „Dobro došli.“ / „Welcome.“. Nazivi apartmana i svi podaci ostaju isti.

= 1.1.0 =
Nadogradnja bez izmjene postojećih linkova i šifrovanih postavki.
Obavještenja sa rasporedom, statusom, ciljanjem apartmana i SR/EN tekstom.
Automatski spisak iz rooms sadržaja, ručni apartmani i posebna uputstva.
Stalni apartmanski vodiči bez gostujućih ključeva; lokalni QR generator i PNG preuzimanje.
Centralni promjenjivi logo, jasno označena promjenjiva vremena prijave/odjave.

= 1.0.0 =
Prvo izdanje: SR/EN predložak, zajedničke postavke, fotografije, privatni linkovi, istek, poništavanje i kopiranje poruka.
