<?php
/**
 * Plugin Name: Memory – uputstva za goste
 * Description: Privatna SR/EN uputstva za goste, obavještenja i Wellness rezervacije saune u istom panelu.
 * Version: 1.2.2
 * Requires at least: 6.4
 * Requires PHP: 8.0
 * Author: Memory Residence
 * Text Domain: memory-guest-guide
 */

if (!defined('ABSPATH')) exit;
define('MGG_VERSION', '1.2.2');
define('MGG_FILE', __FILE__);
define('MGG_DIR', __DIR__ . '/');

// Cache plugins must additionally exclude the guide URL in their settings.
if (isset($_GET['memory_guest_guide']) || preg_match('~/uputstvo-za-dolazak(?:/|$)~', (string) ($_SERVER['REQUEST_URI'] ?? ''))) {
    if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
    if (!defined('DONOTCACHEDB')) define('DONOTCACHEDB', true);
    if (!defined('DONOTCACHEOBJECT')) define('DONOTCACHEOBJECT', true);
}

require_once MGG_DIR . 'includes/class-mgg-store.php';
require_once MGG_DIR . 'includes/class-mgg-apartments.php';
require_once MGG_DIR . 'includes/class-mgg-notices.php';
require_once MGG_DIR . 'includes/class-mgg-admin.php';
require_once MGG_DIR . 'includes/class-mgg-wellness.php';
require_once MGG_DIR . 'includes/class-mgg-wellness-admin.php';
require_once MGG_DIR . 'includes/class-mgg-guest.php';

register_activation_hook(__FILE__, ['MGG_Store', 'activate']);
register_deactivation_hook(__FILE__, ['MGG_Guest', 'deactivate']);
add_action('init', ['MGG_Store', 'upgrade'], 0);
add_action('init', ['MGG_Wellness', 'upgrade'], 1);
add_action('init', ['MGG_Apartments', 'register']);
add_action('init', ['MGG_Guest', 'rewrite']);
add_filter('query_vars', static function ($vars) { $vars[] = 'memory_guest_guide'; return $vars; });
add_action('template_redirect', ['MGG_Guest', 'route'], 0);
add_action('admin_menu', ['MGG_Admin', 'menu']);
add_action('admin_menu', ['MGG_Wellness_Admin', 'menu'], 20);
add_action('admin_enqueue_scripts', ['MGG_Wellness_Admin', 'assets']);
add_action('admin_enqueue_scripts', ['MGG_Wellness_Admin', 'badge_assets']);
add_action('wp_ajax_mgg_wellness_count', ['MGG_Wellness_Admin', 'badge_ajax']);
add_action('admin_enqueue_scripts', ['MGG_Admin', 'assets']);
add_action('admin_post_mgg_save_link', ['MGG_Admin', 'save_link']);
add_action('admin_post_mgg_link_action', ['MGG_Admin', 'link_action']);
add_action('admin_post_mgg_save_settings', ['MGG_Admin', 'save_settings']);
add_action('admin_post_mgg_save_apartment', ['MGG_Apartments', 'save']);
add_action('admin_post_mgg_apartment_link', ['MGG_Apartments', 'link_action']);
add_action('admin_post_mgg_save_notice', ['MGG_Notices', 'save']);
add_action('admin_post_mgg_notice_action', ['MGG_Notices', 'action']);
add_action('admin_post_mgg_wellness_admin', ['MGG_Wellness_Admin', 'action']);
