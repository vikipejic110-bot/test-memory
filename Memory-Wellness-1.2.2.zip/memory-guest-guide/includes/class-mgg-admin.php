<?php
if (!defined('ABSPATH')) exit;

final class MGG_Admin {
    public static function menu(): void {
        add_menu_page('Uputstva za goste', 'Uputstva za goste', 'manage_options', 'memory-guest-guide', [self::class, 'listing'], 'dashicons-admin-network', 32);
        add_submenu_page('memory-guest-guide', 'Rezervacije i linkovi', 'Rezervacije i linkovi', 'manage_options', 'memory-guest-guide', [self::class, 'listing']);
        add_submenu_page('memory-guest-guide', 'Novi link', 'Novi link', 'manage_options', 'memory-guest-guide-new', [self::class, 'edit']);
        add_submenu_page('memory-guest-guide', 'Apartmani', 'Apartmani', 'manage_options', 'memory-guest-guide-apartments', ['MGG_Apartments', 'listing']);
        add_submenu_page('memory-guest-guide', 'Obavještenja', 'Obavještenja', 'manage_options', 'memory-guest-guide-notices', ['MGG_Notices', 'listing']);
        add_submenu_page('memory-guest-guide', 'Zajedničko uputstvo', 'Zajedničko uputstvo', 'manage_options', 'memory-guest-guide-settings', [self::class, 'settings']);
    }

    public static function guard(): void {
        if (!current_user_can('manage_options')) wp_die('Nemate dozvolu za ovu radnju.', '', ['response' => 403]);
    }

    public static function assets(string $hook): void {
        if (!str_contains($hook, 'memory-guest-guide')) return;
        wp_enqueue_media();
        wp_enqueue_style('mgg-admin', plugins_url('assets/admin.css', MGG_FILE), [], MGG_VERSION);
        wp_enqueue_script('mgg-qr', plugins_url('assets/vendor/qrcode.js', MGG_FILE), [], '2.0.4', true);
        wp_enqueue_script('mgg-admin', plugins_url('assets/admin.js', MGG_FILE), ['mgg-qr'], MGG_VERSION, true);
    }

    public static function url(string $page = '', array $args = []): string {
        return add_query_arg(array_merge(['page' => 'memory-guest-guide' . $page], $args), admin_url('admin.php'));
    }

    public static function date(int $time): string {
        return wp_date('d.m.Y. H:i', $time, wp_timezone());
    }

    public static function listing(): void {
        self::guard();
        global $wpdb;
        $page = max(1, absint($_GET['paged'] ?? 1));
        $limit = 20;
        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM " . MGG_Store::table() . " WHERE kind = 'reservation'");
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . MGG_Store::table() . " WHERE kind = 'reservation' ORDER BY id DESC LIMIT %d OFFSET %d", $limit, ($page - 1) * $limit));
        echo '<div class="wrap mgg-admin"><h1>Uputstva za goste <a class="page-title-action" href="' . esc_url(self::url('-new')) . '">Novi link</a></h1>';
        echo '<p>Za svaku rezervaciju kreirajte novi link. Uputstvo i fotografije podešavate jednom; SmartPierre pristup je zaseban za svakog gosta.</p>';
        if (isset($_GET['saved'])) echo '<div class="notice notice-success"><p>Promjena je sačuvana.</p></div>';
        echo '<div class="mgg-note">Istek ili poništavanje linka zatvara pristup ovom uputstvu. Važenje digitalnog ključa podesite i u aplikaciji SmartPierre.</div>';
        echo '<p class="description">Prije prvog slanja: u <a href="' . esc_url(self::url('-settings')) . '">Zajedničkom uputstvu</a> unesite Wi-Fi lozinku. U SpeedyCache / CDN podešavanjima izuzmite <code>/uputstvo-za-dolazak/*</code> i zahtjeve sa parametrom <code>memory_guest_guide</code> iz keširanja.</p>';
        echo '<table class="widefat striped"><thead><tr><th>Rezervacija</th><th>Status i istek</th><th>Link i poruka za gosta</th><th>Radnje</th></tr></thead><tbody>';
        foreach ($rows as $row) {
            try {
                $p = MGG_Store::payload($row);
                $url = MGG_Store::url($row);
                $url_en = MGG_Store::url($row, 'en');
            } catch (Throwable $error) {
                echo '<tr><td colspan="4">' . esc_html('Zapis #' . $row->id . ': ' . $error->getMessage()) . '</td></tr>';
                continue;
            }
            $label = $p['label'] ?: 'Rezervacija #' . $row->id;
            $status = (int) $row->revoked_at > 0 ? 'Poništen' : (MGG_Store::active($row) ? 'Aktivan' : 'Istekao');
            $message = "Dobro došli u Memory Residence!\nUputstvo za dolazak i vaš digitalni pristup:\n{$url}\nLink važi do " . self::date((int) $row->expires_at) . ".\nMolimo vas da ga ne dijelite sa drugim osobama.";
            $message_en = "Welcome to Memory Residence!\nYour arrival guide and digital access:\n{$url_en}\nThis guide link expires on " . wp_date('d M Y H:i', (int) $row->expires_at) . ".\nPlease do not share it with others.";
            echo '<tr><td><strong>' . esc_html($label) . '</strong><br>' . esc_html($p['apartment'] ? 'Apartman: ' . $p['apartment'] : '') . '<br><small>Kreirano: ' . esc_html(self::date((int) $row->created_at)) . '</small></td>';
            echo '<td><span class="mgg-status ' . (MGG_Store::active($row) ? 'active' : '') . '">' . esc_html($status) . '</span><p>' . esc_html(self::date((int) $row->expires_at)) . '</p></td>';
            echo '<td class="mgg-share"><input class="widefat" aria-label="Link za gosta" readonly value="' . esc_attr($url) . '"><p>';
            foreach (['Kopiraj link' => $url, 'Poruka SR' => $message, 'Message EN' => $message_en] as $text => $value) {
                echo '<button type="button" class="button" data-mgg-copy="' . esc_attr($value) . '">' . esc_html($text) . '</button> ';
            }
            echo '<button class="button" type="button" data-mgg-qr="' . esc_attr($url) . '">QR kod</button> <a class="button" target="_blank" rel="noopener noreferrer" href="' . esc_url($url) . '">Otvori</a></p></td><td><a class="button" href="' . esc_url(self::url('-new', ['id' => $row->id])) . '">Uredi</a>';
            if ((int) $row->revoked_at === 0) self::action_form($row, 'revoke', 'Poništi link');
            self::action_form($row, 'delete', 'Obriši zapis');
            echo '</td></tr>';
        }
        if (!$rows) echo '<tr><td colspan="4">Još nema linkova. Kliknite „Novi link“ za prvu rezervaciju.</td></tr>';
        echo '</tbody></table>';
        if ($total > $limit) echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post(paginate_links(['base' => add_query_arg('paged', '%#%', self::url()), 'format' => '', 'current' => $page, 'total' => (int) ceil($total / $limit)])) . '</div></div>';
        echo '<p><small>Vrijeme je prikazano u WordPress vremenskoj zoni: ' . esc_html(wp_timezone_string()) . '. Poruke se kopiraju; dodatak ih ne šalje automatski.</small></p><p role="status" id="mgg-copy-status" aria-live="polite"></p></div>';
    }

    private static function action_form(object $row, string $verb, string $label): void {
        echo '<form method="post" class="mgg-inline" action="' . esc_url(admin_url('admin-post.php')) . '" data-mgg-confirm="' . esc_attr($verb === 'delete' ? 'Obrisati ovaj zapis? Link će prestati da radi.' : 'Poništiti ovaj link? Gost više neće moći otvoriti uputstvo.') . '">';
        wp_nonce_field('mgg_' . $verb . '_' . $row->id);
        echo '<input type="hidden" name="action" value="mgg_link_action"><input type="hidden" name="verb" value="' . esc_attr($verb) . '"><input type="hidden" name="id" value="' . (int) $row->id . '"><button class="button" type="submit">' . esc_html($label) . '</button></form>';
    }

    public static function edit(): void {
        self::guard();
        try {
            $settings = MGG_Store::settings();
            $id = absint($_GET['id'] ?? 0);
            $row = $id ? MGG_Store::by_id($id) : null;
            if ($id && !$row) wp_die('Zapis ne postoji.');
            if ($row && ($row->kind ?? 'reservation') !== 'reservation') wp_die('Stalni link uređuje se u odjeljku Apartmani.');
            $p = $row ? MGG_Store::payload($row) : ['label' => '', 'apartment' => '', 'provider_url' => '', 'door_image' => 0];
        } catch (Throwable $e) { wp_die(esc_html($e->getMessage())); }
        echo '<div class="wrap mgg-admin"><h1>' . ($row ? 'Uredi rezervaciju' : 'Novi link za gosta') . '</h1><p>Uputstvo je već složeno prema dostavljenom PDF-u. Zalijepite pristupni link iz aplikacije SmartPierre.</p>';
        if ($row && (int) $row->revoked_at > 0) echo '<div class="notice notice-warning"><p>Ovaj link je poništen. Uređivanje ga neće ponovo aktivirati. Kreirajte novi link za novu rezervaciju.</p></div>';
        echo '<form class="mgg-panel" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('mgg_save_link');
        echo '<input type="hidden" name="action" value="mgg_save_link"><input type="hidden" name="id" value="' . (int) $id . '"><table class="form-table">';
        self::input('label', 'Oznaka rezervacije', $p['label'], 'text', 'Oznaka za lakše pronalaženje. Ako unesete ime gosta, ono se predlaže u Wellness obrascu; gost ga može izmijeniti.');
        echo '<tr><th><label for="mgg-apartment_id">Izaberite apartman</label></th><td>';
        MGG_Apartments::select('apartment_id', MGG_Apartments::resolve($p), 'Bez izbora – koristi raniji tekstualni unos');
        echo '<p class="description">Odabrani apartman određuje posebna uputstva i obavještenja. Raniji tekst ostaje sačuvan.</p></td></tr>';
        self::input('apartment', 'Apartman / broj vrata', $p['apartment'], 'text', 'Opciono, npr. 001 – Blue Memory. Prikazuje se gostu.');
        self::input('provider_url', 'SmartPierre link', $p['provider_url'], 'url', 'Zalijepite zaseban https://keys.smartpierre.com/... link za ovu rezervaciju.', true);
        if ($row) self::input('expires', 'Važi do', wp_date('Y-m-d\TH:i', (int) $row->expires_at, wp_timezone()), 'datetime-local', 'Izmjena datuma produžava ili skraćuje važenje istog linka.', true);
        else {
            echo '<tr><th><label for="mgg-days">Važenje linka</label></th><td><input id="mgg-days" name="days" type="number" min="1" max="365" required value="' . (int) $settings['days'] . '"> dana<p class="description">Računa se od trenutka kreiranja. Podrazumijevano 30 dana.</p></td></tr>';
        }
        self::image_field('door_image', 'Fotografija vrata za ovaj apartman', (int) ($p['door_image'] ?? 0), 'Opciono. Ako ostane prazno, koristi se zajednička fotografija kao primjer.');
        echo '</table>';
        submit_button($row ? 'Sačuvaj promjene' : 'Kreiraj link za gosta');
        echo '</form></div>';
    }

    public static function input(string $name, string $label, string $value, string $type = 'text', string $help = '', bool $required = false): void {
        echo '<tr><th><label for="mgg-' . esc_attr($name) . '">' . esc_html($label) . '</label></th><td><input class="regular-text" id="mgg-' . esc_attr($name) . '" name="' . esc_attr($name) . '" type="' . esc_attr($type) . '" value="' . esc_attr($value) . '" ' . ($required ? 'required' : '') . '><p class="description">' . esc_html($help) . '</p></td></tr>';
    }

    public static function image_field(string $name, string $label, int $id, string $help = ''): void {
        $url = $id ? wp_get_attachment_image_url($id, 'thumbnail') : '';
        echo '<tr><th>' . esc_html($label) . '</th><td class="mgg-media"><input type="hidden" name="' . esc_attr($name) . '" value="' . $id . '"><img alt="" class="mgg-image-preview" ' . ($url ? 'src="' . esc_url($url) . '"' : 'hidden') . '><p><button class="button mgg-pick-image" type="button">Izaberi / učitaj sliku</button> <button class="button mgg-remove-image" type="button">Ukloni izbor</button></p><p class="description">' . esc_html($help) . '</p></td></tr>';
    }

    public static function save_link(): void {
        self::guard();
        check_admin_referer('mgg_save_link');
        try {
            $id = absint($_POST['id'] ?? 0);
            $existing = $id ? MGG_Store::by_id($id) : null;
            if ($id && (!$existing || ($existing->kind ?? 'reservation') !== 'reservation')) throw new InvalidArgumentException('Rezervacija ne postoji.');
            $apartment_id = absint($_POST['apartment_id'] ?? 0);
            if ($apartment_id && !MGG_Apartments::valid($apartment_id)) throw new InvalidArgumentException('Izaberite objavljen apartman.');
            $image = self::image_id(absint($_POST['door_image'] ?? 0));
            $payload = array_merge($existing ? MGG_Store::payload($existing) : [], [
                'label' => substr(sanitize_text_field(wp_unslash($_POST['label'] ?? '')), 0, 160),
                'apartment' => substr(sanitize_text_field(wp_unslash($_POST['apartment'] ?? '')), 0, 160),
                'provider_url' => MGG_Store::provider_url(wp_unslash($_POST['provider_url'] ?? '')),
                'door_image' => $image,
                'apartment_id' => $apartment_id,
            ]);
            if ($id) {
                if (!MGG_Store::by_id($id)) throw new InvalidArgumentException('Zapis ne postoji.');
                $raw_date = sanitize_text_field(wp_unslash($_POST['expires'] ?? ''));
                $date = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', $raw_date, wp_timezone());
                if (!$date || $date->format('Y-m-d\TH:i') !== $raw_date) throw new InvalidArgumentException('Datum isteka nije ispravan.');
                global $wpdb;
                $ok = $wpdb->update(MGG_Store::table(), ['payload' => MGG_Store::encrypt(wp_json_encode($payload, JSON_UNESCAPED_UNICODE)), 'expires_at' => $date->getTimestamp(), 'apartment_id' => $apartment_id], ['id' => $id], ['%s','%d','%d'], ['%d']);
                if ($ok === false) throw new RuntimeException('Čuvanje nije uspjelo.');
            } else {
                $days = (int) ($_POST['days'] ?? 30);
                if ($days < 1 || $days > 365) throw new InvalidArgumentException('Izaberite važenje od 1 do 365 dana.');
                MGG_Store::create($payload, time() + $days * DAY_IN_SECONDS);
            }
        } catch (Throwable $e) { wp_die(esc_html($e->getMessage()), '', ['response' => 400, 'back_link' => true]); }
        wp_safe_redirect(self::url('', ['saved' => 1]));
        exit;
    }

    public static function link_action(): void {
        self::guard();
        $id = absint($_POST['id'] ?? 0);
        $verb = sanitize_key($_POST['verb'] ?? '');
        if (!in_array($verb, ['revoke','delete'], true)) wp_die('Nepoznata radnja.', '', ['response' => 400]);
        check_admin_referer('mgg_' . $verb . '_' . $id);
        $row = MGG_Store::by_id($id);
        if (!$row || ($row->kind ?? 'reservation') !== 'reservation') wp_die('Rezervacija ne postoji.', '', ['response' => 400]);
        global $wpdb;
        if ($verb === 'delete') $wpdb->delete(MGG_Store::table(), ['id' => $id], ['%d']);
        else $wpdb->update(MGG_Store::table(), ['revoked_at' => time()], ['id' => $id], ['%d'], ['%d']);
        wp_safe_redirect(self::url('', ['saved' => 1]));
        exit;
    }

    public static function settings(): void {
        self::guard();
        try { $s = MGG_Store::settings(); } catch (Throwable $e) { wp_die(esc_html($e->getMessage())); }
        echo '<div class="wrap mgg-admin"><h1>Zajedničko uputstvo</h1><p>Tekst i fotografije iz dostavljenog uputstva su već pripremljeni. Ovdje ih uredite jednom; svi važeći linkovi koriste ovo uputstvo.</p>';
        if (isset($_GET['saved'])) echo '<div class="notice notice-success"><p>Uputstvo je sačuvano.</p></div>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="mgg-panel">';
        wp_nonce_field('mgg_save_settings');
        echo '<input type="hidden" name="action" value="mgg_save_settings"><h2>Osnovni podaci</h2><table class="form-table">';
        self::input('property', 'Naziv objekta', $s['property']);
        self::input('location', 'Lokacija', $s['location']);
        self::image_field('logo_id', 'Logo objekta', (int) $s['logo_id'], 'Prikazuje se centralno na početku vodiča. Bez izbora koristi se logo iz WordPress teme, ako postoji.');
        self::input('wifi_name', 'Wi-Fi mreža', $s['wifi_name']);
        self::input('wifi_password', 'Wi-Fi lozinka', $s['wifi_password'], 'text', 'Unesite jednom. Lozinka se prikazuje samo kroz važeće linkove za goste.');
        self::input('phone', 'Telefon podrške', $s['phone'], 'tel');
        self::input('checkin', 'Prijava od', $s['checkin'], 'time');
        self::input('checkout', 'Odjava do', $s['checkout'], 'time');
        echo '<tr><th><label for="mgg-default-days">Podrazumijevano važenje</label></th><td><input id="mgg-default-days" type="number" name="days" min="1" max="365" value="' . (int) $s['days'] . '" required> dana</td></tr>';
        self::image_field('image_parking', 'Fotografija parking rampe', $s['image_parking'], 'Bez izbora koristi se fotografija iz priloga.');
        self::image_field('image_entrance', 'Fotografija ulaza', $s['image_entrance'], 'Bez izbora koristi se fotografija iz priloga.');
        self::image_field('image_door', 'Primjer vrata apartmana', $s['image_door'], 'Fotografiju za konkretan apartman možete dodati i prilikom kreiranja linka.');
        echo '</table>';
        $labels = self::text_labels();
        foreach (['sr' => 'Srpski – latinica', 'en' => 'English'] as $lang => $heading) {
            echo '<h2>' . esc_html($heading) . '</h2><p>Oznaka <code>{apartman}</code> automatski dodaje broj / naziv apartmana iz rezervacije.</p><table class="form-table">';
            foreach ($labels as $key => $label) echo '<tr><th><label for="mgg-' . esc_attr($lang . '-' . $key) . '">' . esc_html($label) . '</label></th><td><textarea class="large-text" rows="' . (str_ends_with($key, 'title') ? '1' : '3') . '" id="mgg-' . esc_attr($lang . '-' . $key) . '" name="text[' . esc_attr($lang) . '][' . esc_attr($key) . ']">' . esc_textarea($s[$lang][$key]) . '</textarea></td></tr>';
            echo '</table>';
        }
        submit_button('Sačuvaj zajedničko uputstvo');
        echo '</form></div>';
    }

    public static function image_id(int $id): int {
        if ($id && !wp_attachment_is_image($id)) throw new InvalidArgumentException('Izaberite sliku iz biblioteke medija.');
        return $id;
    }

    public static function save_settings(): void {
        self::guard();
        check_admin_referer('mgg_save_settings');
        try {
            $s = MGG_Store::settings();
            foreach (['property','location','wifi_name','wifi_password','phone','checkin','checkout'] as $key) $s[$key] = substr(sanitize_text_field(wp_unslash($_POST[$key] ?? '')), 0, 300);
            foreach (['checkin','checkout'] as $key) if (!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/D', $s[$key])) throw new InvalidArgumentException('Vrijeme prijave ili odjave nije ispravno.');
            $s['days'] = (int) ($_POST['days'] ?? 30);
            if ($s['days'] < 1 || $s['days'] > 365) throw new InvalidArgumentException('Važenje mora biti od 1 do 365 dana.');
            foreach (['image_parking','image_entrance','image_door','logo_id'] as $key) $s[$key] = self::image_id(absint($_POST[$key] ?? 0));
            foreach (['sr','en'] as $lang) foreach (array_keys(MGG_Store::defaults()[$lang]) as $key) $s[$lang][$key] = self::clean($_POST['text'][$lang][$key] ?? '', 12000, true);
            MGG_Store::save_settings($s);
        } catch (Throwable $e) { wp_die(esc_html($e->getMessage()), '', ['response' => 400, 'back_link' => true]); }
        wp_safe_redirect(self::url('-settings', ['saved' => 1]));
        exit;
    }

    public static function clean($value, int $max = 12000, bool $multiline = false): string {
        if (!is_string($value)) throw new InvalidArgumentException('Unos nije ispravan.');
        $value = $multiline ? sanitize_textarea_field(wp_unslash($value)) : sanitize_text_field(wp_unslash($value));
        return function_exists('mb_substr') ? mb_substr($value, 0, $max, 'UTF-8') : wp_check_invalid_utf8(substr($value, 0, $max), true);
    }

    public static function text_labels(): array {
        return ['intro' => 'Uvod', 'wifi_title' => 'Naslov – Wi-Fi', 'wifi_text' => 'Tekst – Wi-Fi', 'parking_title' => 'Naslov – parking', 'parking_text' => 'Tekst – parking', 'entrance_title' => 'Naslov – ulaz', 'entrance_text' => 'Tekst – ulaz', 'door_title' => 'Naslov – apartman', 'door_text' => 'Tekst – apartman', 'footer' => 'Završna napomena'];
    }
}
