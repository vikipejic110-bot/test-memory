<?php
if (!defined('ABSPATH')) exit;

final class MGG_Store {
    public static function table(): string {
        global $wpdb;
        return $wpdb->prefix . 'memory_guest_links';
    }

    public static function activate(): void {
        if (!function_exists('openssl_encrypt') || !in_array('aes-256-gcm', openssl_get_cipher_methods(), true)) {
            wp_die('Dodatak zahtijeva PHP OpenSSL sa podrškom za AES-256-GCM.');
        }
        self::upgrade();
        MGG_Guest::rewrite();
        flush_rewrite_rules();
    }

    public static function upgrade(): void {
        if (get_option('mgg_db_version') === '1.1.0') return;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table();
        $charset = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            token_hash char(64) NOT NULL,
            token_secret longtext NOT NULL,
            payload longtext NOT NULL,
            created_at bigint(20) unsigned NOT NULL,
            expires_at bigint(20) unsigned NOT NULL,
            revoked_at bigint(20) unsigned NOT NULL DEFAULT 0,
            kind varchar(20) NOT NULL DEFAULT 'reservation',
            apartment_id bigint(20) unsigned NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY token_hash (token_hash),
            KEY expires_at (expires_at),
            KEY apartment_kind (apartment_id,kind)
        ) {$charset};");
        $notices = $wpdb->prefix . 'memory_guest_notices';
        dbDelta("CREATE TABLE {$notices} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            apartment_id bigint(20) unsigned NOT NULL DEFAULT 0,
            enabled tinyint(1) NOT NULL DEFAULT 1,
            starts_at bigint(20) unsigned NOT NULL DEFAULT 0,
            ends_at bigint(20) unsigned NOT NULL DEFAULT 0,
            payload longtext NOT NULL,
            created_at bigint(20) unsigned NOT NULL,
            updated_at bigint(20) unsigned NOT NULL,
            PRIMARY KEY  (id),
            KEY target_window (apartment_id,enabled,starts_at,ends_at)
        ) {$charset};");
        // An upgrade only adds schema; existing encrypted settings and rows stay intact.
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($notices))) === $notices &&
            $wpdb->get_var("SHOW COLUMNS FROM {$table} LIKE 'kind'")) {
            update_option('mgg_db_version', '1.1.0', false);
        }
    }

    private static function key(): string {
        return hash('sha256', wp_salt('auth') . '|memory-guest-guide-v1|' . wp_salt('secure_auth'), true);
    }

    public static function encrypt(string $plain): string {
        $iv = random_bytes(12);
        $tag = '';
        $cipher = openssl_encrypt($plain, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag, 'MGG1');
        if ($cipher === false) throw new RuntimeException('Šifrovanje nije uspjelo.');
        return 'v1:' . base64_encode($iv . $tag . $cipher);
    }

    public static function decrypt(string $cipher): ?string {
        if (!str_starts_with($cipher, 'v1:')) return null;
        $raw = base64_decode(substr($cipher, 3), true);
        if ($raw === false || strlen($raw) < 28) return null;
        $plain = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16), 'MGG1');
        return $plain === false ? null : $plain;
    }

    public static function provider_url(string $value): string {
        $value = trim($value);
        $parts = wp_parse_url($value);
        if (strlen($value) > 4096 || preg_match('/[\x00-\x20\x7F]/', $value) || !$parts ||
            strtolower($parts['scheme'] ?? '') !== 'https' || strtolower($parts['host'] ?? '') !== 'keys.smartpierre.com' ||
            isset($parts['user']) || isset($parts['pass']) || (isset($parts['port']) && $parts['port'] !== 443) || empty($parts['path']) || $parts['path'] === '/') {
            throw new InvalidArgumentException('Zalijepite potpun HTTPS pristupni link iz aplikacije SmartPierre (keys.smartpierre.com).');
        }
        return esc_url_raw($value, ['https']);
    }

    public static function defaults(): array {
        return [
            'property' => 'Memory Residence', 'location' => 'Banja Luka',
            'wifi_name' => 'AM', 'wifi_password' => '', 'phone' => '+387 66 888 600',
            'checkin' => '14:00', 'checkout' => '10:00', 'days' => 30,
            'image_parking' => 0, 'image_entrance' => 0, 'image_door' => 0, 'logo_id' => 0,
            'sr' => [
                'intro' => 'Dobro došli! Pratite korake redom kako biste jednostavno pristupili parkingu, objektu i svom apartmanu.',
                'wifi_title' => 'Povežite se na Wi-Fi',
                'wifi_text' => 'Prije otvaranja rampe, povežite telefon na Wi-Fi mrežu kako biste mogli otvoriti digitalni pristupni link.',
                'parking_title' => 'Otvorite rampu za parking',
                'parking_text' => 'Ako dolazite automobilom, otvorite digitalni pristup i pratite uputstva u aplikaciji za otvaranje rampe.',
                'entrance_title' => 'Uđite u objekat',
                'entrance_text' => 'Prepoznajte ulaz prema fotografiji. Otvorite digitalni pristup i pratite uputstva za otključavanje ulaznih vrata.',
                'door_title' => 'Pronađite vrata apartmana',
                'door_text' => 'Kada uđete u objekat, pronađite vrata sa brojem apartmana navedenim u rezervaciji. {apartman}',
                'footer' => 'Molimo vas da svoje digitalne pristupne linkove ne dijelite sa drugim osobama.',
            ],
            'en' => [
                'intro' => 'Welcome! Follow the steps in order to access the parking area, building and your apartment.',
                'wifi_title' => 'Connect to Wi-Fi',
                'wifi_text' => 'Before opening the parking barrier, connect your phone to Wi-Fi so you can open the digital access link.',
                'parking_title' => 'Open the parking barrier',
                'parking_text' => 'If you arrive by car, open your digital access and follow the instructions in the app to open the parking barrier.',
                'entrance_title' => 'Enter the building',
                'entrance_text' => 'Identify the entrance using the photo. Open your digital access and follow the instructions to unlock the main entrance.',
                'door_title' => 'Find your apartment door',
                'door_text' => 'Once inside the building, find the apartment number shown in your reservation. {apartman}',
                'footer' => 'Please do not share your digital access links with other people.',
            ],
        ];
    }

    public static function settings(): array {
        $raw = (string) get_option('mgg_settings', '');
        if ($raw === '') return self::defaults();
        $plain = self::decrypt($raw);
        if ($plain === null) throw new RuntimeException('Postavke nije moguće otvoriti. Provjerite WordPress sigurnosne ključeve.');
        $saved = json_decode($plain, true);
        if (!is_array($saved)) throw new RuntimeException('Postavke nisu ispravne.');
        return array_replace_recursive(self::defaults(), $saved);
    }

    public static function save_settings(array $settings): void {
        update_option('mgg_settings', self::encrypt(wp_json_encode($settings, JSON_UNESCAPED_UNICODE)), false);
    }

    public static function create(array $payload, int $expires, string $kind = 'reservation'): object {
        if (!in_array($kind, ['reservation','apartment'], true)) throw new InvalidArgumentException('Nepoznata vrsta linka.');
        if ($kind === 'reservation' && $expires <= time()) throw new InvalidArgumentException('Datum isteka mora biti u budućnosti.');
        if ($kind === 'reservation') $payload['provider_url'] = self::provider_url($payload['provider_url'] ?? '');
        else { $expires = 0; $payload['provider_url'] = ''; }
        $token = rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
        global $wpdb;
        $ok = $wpdb->insert(self::table(), [
            'token_hash' => hash('sha256', $token), 'token_secret' => self::encrypt($token),
            'payload' => self::encrypt(wp_json_encode($payload, JSON_UNESCAPED_UNICODE)),
            'created_at' => time(), 'expires_at' => $expires, 'revoked_at' => 0,
            'kind' => $kind, 'apartment_id' => absint($payload['apartment_id'] ?? 0),
        ], ['%s','%s','%s','%d','%d','%d','%s','%d']);
        if (!$ok) throw new RuntimeException('Čuvanje linka nije uspjelo.');
        return self::by_id((int) $wpdb->insert_id);
    }

    public static function by_id(int $id): ?object {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table() . ' WHERE id = %d', $id));
    }

    public static function by_token(string $token): ?object {
        if (!preg_match('/^[A-Za-z0-9_-]{43}$/D', $token)) return null;
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table() . ' WHERE token_hash = %s', hash('sha256', $token)));
    }

    public static function payload(object $row): array {
        $plain = self::decrypt($row->payload);
        $value = $plain === null ? null : json_decode($plain, true);
        if (!is_array($value)) throw new RuntimeException('Podatke linka nije moguće otvoriti. Provjerite WordPress sigurnosne ključeve.');
        return $value;
    }

    public static function active(object $row): bool {
        return (int) $row->revoked_at === 0 && ((int) $row->expires_at > time() ||
            (($row->kind ?? 'reservation') === 'apartment' && (int) $row->expires_at === 0));
    }

    public static function url(object $row, string $lang = ''): string {
        $token = self::decrypt($row->token_secret);
        if ($token === null) throw new RuntimeException('Link nije moguće otvoriti.');
        $url = get_option('permalink_structure')
            ? home_url('/uputstvo-za-dolazak/' . $token . '/')
            : add_query_arg('memory_guest_guide', $token, home_url('/'));
        return in_array($lang, ['sr','en'], true) ? add_query_arg('lang', $lang, $url) : $url;
    }
}
