<?php
if (!defined('ABSPATH')) exit;

final class MGG_Apartments {
    public static function register(): void {
        register_post_type('mgg_apartment', ['label' => 'Apartmani za vodič', 'public' => false, 'show_ui' => false, 'show_in_rest' => false, 'rewrite' => false, 'supports' => ['title']]);
    }

    public static function all(): array {
        return get_posts(['post_type' => ['rooms','mgg_apartment'], 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC', 'suppress_filters' => false]);
    }

    public static function valid(int $id): bool {
        $post = $id ? get_post($id) : null;
        return $post && $post->post_status === 'publish' && in_array($post->post_type, ['rooms','mgg_apartment'], true);
    }

    public static function config(int $id): array {
        $raw = (string) get_post_meta($id, '_mgg_guide_config', true);
        if ($raw === '') return [];
        $plain = MGG_Store::decrypt($raw);
        $value = $plain === null ? null : json_decode($plain, true);
        if (!is_array($value)) throw new RuntimeException('Uputstvo apartmana nije moguće otvoriti.');
        return $value;
    }

    private static function normalize(string $value): string {
        $value = remove_accents($value);
        $value = function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
        return trim(preg_replace('/[^\p{L}\p{N}]+/u', ' ', $value));
    }

    public static function resolve(array $payload): int {
        $id = absint($payload['apartment_id'] ?? 0);
        // An explicitly selected apartment must never fall through to a different one.
        if ($id) return self::valid($id) ? $id : 0;
        $legacy = self::normalize((string) ($payload['apartment'] ?? ''));
        if ($legacy === '') return 0;
        $bare = preg_replace('/^(?:(?:apartman|apartment) )?\d+ /', '', $legacy);
        $matches = [];
        foreach (self::all() as $post) {
            $title = self::normalize($post->post_title);
            if ($title !== '' && ($legacy === $title || $bare === $title)) { $matches[] = $post->ID; continue; }
            try { $cfg = self::config($post->ID); } catch (Throwable $e) { continue; }
            $code = self::normalize($cfg['code'] ?? '');
            if ($code !== '' && $legacy === $code) $matches[] = $post->ID;
        }
        return count($matches) === 1 ? (int) $matches[0] : 0;
    }

    public static function label(int $id): string {
        if (!self::valid($id)) return '';
        $c = self::config($id);
        return trim(($c['code'] ?? '') . ' ' . get_post($id)->post_title);
    }

    public static function effective(array $settings, int $id): array {
        if (!$id || !self::valid($id)) return $settings;
        $c = self::config($id);
        unset($c['code']);
        return array_replace_recursive($settings, $c);
    }

    public static function select(string $name, int $selected = 0, string $zero = 'Svi apartmani'): void {
        echo '<select id="mgg-' . esc_attr($name) . '" name="' . esc_attr($name) . '"><option value="0">' . esc_html($zero) . '</option>';
        foreach (self::all() as $p) echo '<option value="' . (int) $p->ID . '" ' . selected($selected, $p->ID, false) . '>' . esc_html(self::label($p->ID)) . '</option>';
        echo '</select>';
    }

    public static function permanent(int $id): ?object {
        $row = MGG_Store::by_id(absint(get_post_meta($id, '_mgg_link_id', true)));
        if ($row && ($row->kind ?? '') === 'apartment' && (int) $row->apartment_id === $id) return $row;
        return null;
    }

    public static function listing(): void {
        MGG_Admin::guard();
        $id = absint($_GET['id'] ?? 0);
        if ($id || isset($_GET['new'])) { self::editor($id); return; }
        echo '<div class="wrap mgg-admin"><h1>Apartmani <a class="page-title-action" href="' . esc_url(MGG_Admin::url('-apartments', ['new' => 1])) . '">Dodaj ručno</a></h1><p>Objavljeni apartmani iz sadržaja „Rooms“ prikazuju se automatski. Njihovi nazivi se uređuju na izvornom sadržaju; ovdje podešavate samo vodič za goste.</p>';
        if (isset($_GET['saved'])) echo '<div class="notice notice-success"><p>Promjena je sačuvana.</p></div>';
        echo '<div class="mgg-note">Stalni link/QR apartmana prikazuje njegova uputstva i obavještenja. Ne sadrži SmartPierre ključ bilo kojeg gosta. Za digitalni ključ i dalje koristite zaseban link rezervacije.</div><table class="widefat striped"><thead><tr><th>Apartman</th><th>Izvor</th><th>Stalni link i QR kod</th><th>Uputstvo</th></tr></thead><tbody>';
        foreach (self::all() as $post) {
            try {
                $row = self::permanent($post->ID);
                echo '<tr><td><strong>' . esc_html(self::label($post->ID)) . '</strong></td><td>' . ($post->post_type === 'rooms' ? 'Sa sajta' : 'Ručno dodat') . '</td><td>';
                if ($row && MGG_Store::active($row)) {
                    $url = MGG_Store::url($row);
                    echo '<input class="widefat" aria-label="Stalni link apartmana" readonly value="' . esc_attr($url) . '"><p><button class="button" data-mgg-copy="' . esc_attr($url) . '">Kopiraj link</button> <button class="button" data-mgg-qr="' . esc_attr($url) . '">QR kod</button> <a class="button" target="_blank" rel="noopener noreferrer" href="' . esc_url($url) . '">Otvori</a></p>';
                    self::link_form($post->ID, 'revoke', 'Poništi stalni link');
                } else self::link_form($post->ID, 'create', $row ? 'Kreiraj novi link / QR' : 'Kreiraj stalni link / QR');
                echo '</td><td><a class="button" href="' . esc_url(MGG_Admin::url('-apartments', ['id' => $post->ID])) . '">Uredi uputstvo</a></td></tr>';
            } catch (Throwable $e) { echo '<tr><td colspan="4">' . esc_html($e->getMessage()) . '</td></tr>'; }
        }
        if (!self::all()) echo '<tr><td colspan="4">Nema objavljenih apartmana. Kliknite „Dodaj ručno“.</td></tr>';
        echo '</tbody></table><p id="mgg-copy-status" role="status" aria-live="polite"></p></div>';
    }

    private static function link_form(int $id, string $verb, string $label): void {
        echo '<form method="post" class="mgg-inline" action="' . esc_url(admin_url('admin-post.php')) . '" ' . ($verb === 'revoke' ? 'data-mgg-confirm="Poništiti stalni link? Ranije odštampani QR kod za ovaj link više neće raditi."' : '') . '>';
        wp_nonce_field('mgg_apartment_link_' . $id);
        echo '<input type="hidden" name="action" value="mgg_apartment_link"><input type="hidden" name="id" value="' . $id . '"><input type="hidden" name="verb" value="' . esc_attr($verb) . '"><button class="button" type="submit">' . esc_html($label) . '</button></form>';
    }

    public static function link_action(): void {
        MGG_Admin::guard();
        $id = absint($_POST['id'] ?? 0);
        check_admin_referer('mgg_apartment_link_' . $id);
        try {
            if (!self::valid($id)) throw new InvalidArgumentException('Apartman ne postoji.');
            $verb = sanitize_key($_POST['verb'] ?? '');
            $row = self::permanent($id);
            if ($verb === 'create') {
                if (!$row || !MGG_Store::active($row)) {
                    $row = MGG_Store::create(['label' => '', 'apartment' => '', 'apartment_id' => $id, 'door_image' => 0], 0, 'apartment');
                    update_post_meta($id, '_mgg_link_id', $row->id);
                }
            } elseif ($verb === 'revoke' && $row) {
                global $wpdb;
                $wpdb->update(MGG_Store::table(), ['revoked_at' => time()], ['id' => $row->id], ['%d'], ['%d']);
            } else throw new InvalidArgumentException('Nepoznata radnja.');
        } catch (Throwable $e) { wp_die(esc_html($e->getMessage()), '', ['response' => 400, 'back_link' => true]); }
        wp_safe_redirect(MGG_Admin::url('-apartments', ['saved' => 1])); exit;
    }

    private static function editor(int $id): void {
        try {
            if ($id && !self::valid($id)) throw new InvalidArgumentException('Apartman ne postoji.');
            $post = $id ? get_post($id) : null;
            $c = $id ? self::config($id) : [];
            $shared = MGG_Store::settings();
        } catch (Throwable $e) { wp_die(esc_html($e->getMessage())); }
        echo '<div class="wrap mgg-admin"><h1>' . esc_html($post ? 'Uputstvo: ' . $post->post_title : 'Dodaj apartman ručno') . '</h1><p>Prazna polja koriste zajedničko uputstvo. Promjene su dostupne i preko postojećih linkova za taj apartman.</p><form class="mgg-panel" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('mgg_save_apartment');
        echo '<input type="hidden" name="action" value="mgg_save_apartment"><input type="hidden" name="id" value="' . $id . '"><table class="form-table">';
        if (!$post || $post->post_type === 'mgg_apartment') MGG_Admin::input('manual_title', 'Naziv apartmana', $post ? $post->post_title : '', 'text', '', true);
        else echo '<tr><th>Naziv sa sajta</th><td><strong>' . esc_html($post->post_title) . '</strong> <a href="' . esc_url(get_edit_post_link($id, 'raw')) . '">Uredi izvorni apartman</a></td></tr>';
        MGG_Admin::input('code', 'Broj / oznaka apartmana', $c['code'] ?? '', 'text', 'Opciono, npr. 001.');
        foreach (['wifi_name' => 'Wi-Fi mreža', 'wifi_password' => 'Wi-Fi lozinka', 'phone' => 'Telefon podrške'] as $key => $label) MGG_Admin::input($key, $label, $c[$key] ?? '', 'text', 'Prazno koristi zajedničku vrijednost.');
        foreach (['image_parking' => 'Fotografija parkinga', 'image_entrance' => 'Fotografija ulaza', 'image_door' => 'Fotografija vrata'] as $key => $label) MGG_Admin::image_field($key, $label, (int) ($c[$key] ?? 0), 'Bez izbora koristi se zajednička fotografija.');
        echo '</table>';
        foreach (['sr' => 'Srpski', 'en' => 'English'] as $lang => $label) {
            echo '<h2>' . esc_html($label) . '</h2><table class="form-table">';
            foreach (MGG_Admin::text_labels() as $key => $field_label) echo '<tr><th><label for="mgg-apt-' . esc_attr($lang . '-' . $key) . '">' . esc_html($field_label) . '</label></th><td><textarea class="large-text" rows="3" id="mgg-apt-' . esc_attr($lang . '-' . $key) . '" name="text[' . esc_attr($lang) . '][' . esc_attr($key) . ']" placeholder="' . esc_attr($shared[$lang][$key]) . '">' . esc_textarea($c[$lang][$key] ?? '') . '</textarea></td></tr>';
            echo '<tr><th><label for="mgg-info-' . esc_attr($lang) . '">Dodatne informacije</label></th><td><textarea class="large-text" rows="5" id="mgg-info-' . esc_attr($lang) . '" name="info_' . esc_attr($lang) . '">' . esc_textarea($c['info_' . $lang] ?? '') . '</textarea></td></tr></table>';
        }
        submit_button('Sačuvaj uputstvo apartmana');
        echo '</form></div>';
    }

    public static function save(): void {
        MGG_Admin::guard(); check_admin_referer('mgg_save_apartment');
        try {
            $id = absint($_POST['id'] ?? 0);
            if ($id && !self::valid($id)) throw new InvalidArgumentException('Apartman ne postoji.');
            $post = $id ? get_post($id) : null;
            $name = MGG_Admin::clean($_POST['manual_title'] ?? '', 160);
            $c = $id ? self::config($id) : [];
            $c['code'] = MGG_Admin::clean($_POST['code'] ?? '', 80);
            if (!$post || $post->post_type === 'mgg_apartment') {
                if ($name === '') throw new InvalidArgumentException('Unesite naziv apartmana.');
                foreach (self::all() as $other) if ($other->ID !== $id && self::normalize($other->post_title) === self::normalize($name)) throw new InvalidArgumentException('Apartman s tim nazivom već postoji. Izaberite postojeći zapis.');
            }
            if ($c['code'] !== '') foreach (self::all() as $other) {
                if ($other->ID !== $id && (self::config($other->ID)['code'] ?? '') === $c['code']) throw new InvalidArgumentException('Broj / oznaka je već dodijeljen drugom apartmanu.');
            }
            foreach (['wifi_name','wifi_password','phone'] as $key) {
                $v = MGG_Admin::clean($_POST[$key] ?? '', 300);
                if ($v === '') unset($c[$key]); else $c[$key] = $v;
            }
            foreach (['image_parking','image_entrance','image_door'] as $key) {
                $v = MGG_Admin::image_id(absint($_POST[$key] ?? 0));
                if (!$v) unset($c[$key]); else $c[$key] = $v;
            }
            $defaults = MGG_Store::defaults();
            foreach (['sr','en'] as $lang) {
                foreach (array_keys($defaults[$lang]) as $key) {
                    $v = MGG_Admin::clean($_POST['text'][$lang][$key] ?? '', 12000, true);
                    if ($v === '') unset($c[$lang][$key]); else $c[$lang][$key] = $v;
                }
                $v = MGG_Admin::clean($_POST['info_' . $lang] ?? '', 12000, true);
                if ($v === '') unset($c['info_' . $lang]); else $c['info_' . $lang] = $v;
            }
            if (!$post) {
                $created = wp_insert_post(['post_type' => 'mgg_apartment', 'post_status' => 'publish', 'post_title' => wp_slash($name)], true);
                if (is_wp_error($created)) throw new RuntimeException($created->get_error_message());
                $id = (int) $created;
            } elseif ($post->post_type === 'mgg_apartment') {
                $updated = wp_update_post(['ID' => $id, 'post_title' => wp_slash($name)], true);
                if (is_wp_error($updated)) throw new RuntimeException($updated->get_error_message());
            }
            update_post_meta($id, '_mgg_guide_config', MGG_Store::encrypt(wp_json_encode($c, JSON_UNESCAPED_UNICODE)));
        } catch (Throwable $e) { wp_die(esc_html($e->getMessage()), '', ['response' => 400, 'back_link' => true]); }
        wp_safe_redirect(MGG_Admin::url('-apartments', ['saved' => 1])); exit;
    }
}
