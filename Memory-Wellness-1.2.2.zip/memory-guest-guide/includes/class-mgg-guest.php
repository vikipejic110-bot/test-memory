<?php
if (!defined('ABSPATH')) exit;

final class MGG_Guest {
    private static function arrow(): string {
        return '<svg aria-hidden="true" focusable="false" width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M5 19 19 5M5 5h14v14" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    }
    public static function rewrite(): void {
        add_rewrite_rule('^uputstvo-za-dolazak/([A-Za-z0-9_-]{43})/?$', 'index.php?memory_guest_guide=$matches[1]', 'top');
    }

    public static function deactivate(): void {
        global $wp_rewrite;
        unset($wp_rewrite->extra_rules_top['^uputstvo-za-dolazak/([A-Za-z0-9_-]{43})/?$']);
        flush_rewrite_rules();
    }

    private static function headers(int $status = 200): void {
        if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
        status_header($status);
        nocache_headers();
        header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0', true);
        header('CDN-Cache-Control: no-store');
        header('Surrogate-Control: no-store');
        header('X-Robots-Tag: noindex, nofollow, noarchive, nosnippet');
        header('Referrer-Policy: no-referrer');
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header("Content-Security-Policy: default-src 'none'; img-src 'self' https: data:; style-src 'self'; script-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
        header('Content-Type: text/html; charset=UTF-8');
    }

    public static function route(): void {
        $token = get_query_var('memory_guest_guide', '');
        if (isset($_GET['memory_guest_guide'])) $token = wp_unslash($_GET['memory_guest_guide']);
        if ($token === '' && !isset($_GET['memory_guest_guide'])) return;
        if (!is_string($token)) $token = '';
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $wellness = is_string($_GET['mgg_wellness'] ?? null) ? $_GET['mgg_wellness'] : '';
        if (!in_array($method, ['GET','HEAD'], true) && !($method === 'POST' && $wellness === 'request')) {
            self::headers(405);
            header('Allow: GET, HEAD');
            exit;
        }
        $lang = isset($_GET['lang']) && $_GET['lang'] === 'en' ? 'en' : 'sr';
        self::headers();
        $row = MGG_Store::by_token($token);
        if (!$row) self::error($lang, 404);
        if (!MGG_Store::active($row)) self::error($lang, 410);
        try {
            $p = MGG_Store::payload($row);
            $apartment_id = MGG_Apartments::resolve($p);
            $permanent = ($row->kind ?? 'reservation') === 'apartment';
            if ($permanent && !$apartment_id) self::error($lang, 410);
            $s = MGG_Apartments::effective(MGG_Store::settings(), $apartment_id);
            if (empty($p['apartment'])) $p['apartment'] = MGG_Apartments::label($apartment_id);
            $provider = $permanent ? '' : MGG_Store::provider_url($p['provider_url']);
        } catch (Throwable $e) { self::error($lang, 503); }
        if ($wellness !== '') MGG_Wellness::api($row, $lang, $wellness);
        if (isset($_GET['mgg_notices']) && $_GET['mgg_notices'] === '1') {
            wp_send_json(['html' => MGG_Notices::html($apartment_id, $lang)]);
        }
        if (isset($_GET['mgg_open']) && $_GET['mgg_open'] === '1') {
            // Recheck expiry on every click; never fetch or activate the key server-side.
            if (!MGG_Store::active($row)) self::error($lang, 410);
            if ($provider === '') self::error($lang, 404);
            wp_redirect($provider, 302, 'Memory Guest Guide');
            exit;
        }
        if ($method === 'HEAD') exit;
        self::render($row, $p, $s, $lang, $apartment_id);
        exit;
    }

    private static function head(string $lang, string $title): void {
        echo '<!doctype html><html lang="' . ($lang === 'en' ? 'en' : 'sr-Latn') . '" translate="no"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow,noarchive,nosnippet"><meta name="referrer" content="no-referrer"><title>' . esc_html($title) . '</title><link rel="stylesheet" href="' . esc_url(plugins_url('assets/guest.css', MGG_FILE) . '?ver=' . MGG_VERSION) . '"><link rel="stylesheet" href="' . esc_url(plugins_url('assets/vendor/flatpickr.min.css', MGG_FILE) . '?ver=4.6.13') . '"><link rel="stylesheet" href="' . esc_url(plugins_url('assets/date-format.css', MGG_FILE) . '?ver=' . MGG_VERSION) . '"></head><body class="mgg-guest">';
    }

    private static function error(string $lang, int $status): void {
        self::headers($status);
        $en = $lang === 'en';
        self::head($lang, $en ? 'Guest access' : 'Pristup za gosta');
        $title = $status === 410 ? ($en ? 'This link is no longer active' : 'Ovaj link više nije aktivan') : ($en ? 'The guide is unavailable' : 'Uputstvo nije dostupno');
        $body = $status === 410 ? ($en ? 'The link has expired or was cancelled. Please contact your host for a new link.' : 'Link je istekao ili je poništen. Obratite se domaćinu za novi link.') : ($en ? 'Check the complete link or contact your host.' : 'Provjerite da li ste otvorili cijeli link ili kontaktirajte domaćina.');
        echo '<main class="mgg-error"><p class="mgg-eyebrow">MEMORY RESIDENCE</p><h1>' . esc_html($title) . '</h1><p>' . esc_html($body) . '</p></main></body></html>';
        exit;
    }

    private static function image(array $s, string $kind, int $override = 0): string {
        $id = $override ?: (int) ($s['image_' . $kind] ?? 0);
        $url = $id ? wp_get_attachment_image_url($id, 'large') : false;
        return $url ?: plugins_url('assets/' . $kind . '.jpg', MGG_FILE);
    }

    public static function render(object $row, array $p, array $s, string $lang, int $apartment_id = 0): void {
        $en = $lang === 'en';
        $text = $s[$lang];
        $labels = $en ? [
            'guide' => 'Your arrival guide', 'apartment' => 'Apartment', 'access' => 'Open digital access',
            'app' => 'Open SmartPierre to access the parking barrier and entrance.',
            'wifi' => 'Network', 'password' => 'Password', 'copy' => 'Copy password',
            'copied' => 'Copied', 'copy_fail' => 'Select the password to copy it.',
            'help' => 'Need assistance?', 'call' => 'Call your host', 'checkin' => 'CHECK-IN: from', 'checkout' => 'CHECK-OUT: by',
            'valid' => 'Guide link valid until', 'example' => 'Example photo. Follow the apartment number in your reservation.',
            'photo' => ['parking' => 'Parking barrier', 'entrance' => 'Building entrance', 'door' => 'Apartment door'],
        ] : [
            'guide' => 'Vaše uputstvo za dolazak', 'apartment' => 'Apartman', 'access' => 'Otvori digitalni pristup',
            'app' => 'Otvorite SmartPierre za pristup parking rampi i ulaznim vratima.',
            'wifi' => 'Mreža', 'password' => 'Lozinka', 'copy' => 'Kopiraj lozinku',
            'copied' => 'Kopirano', 'copy_fail' => 'Označite lozinku da biste je kopirali.',
            'help' => 'Potrebna vam je pomoć?', 'call' => 'Pozovi domaćina', 'checkin' => 'CHECK-IN: od', 'checkout' => 'CHECK-OUT: do',
            'valid' => 'Link za uputstvo važi do', 'example' => 'Fotografija je primjer. Pratite broj apartmana iz rezervacije.',
            'photo' => ['parking' => 'Rampa za parking', 'entrance' => 'Ulaz u objekat', 'door' => 'Vrata apartmana'],
        ];
        $url = MGG_Store::url($row, $lang);
        $open = add_query_arg('mgg_open', '1', $url);
        $has_key = ($row->kind ?? 'reservation') === 'reservation';
        $phone = preg_replace('/[^+0-9]/', '', $s['phone']);
        self::head($lang, $s['property'] . ' · ' . $labels['guide']);
        echo '<div id="mgg-guide" data-expires="' . (int) $row->expires_at . '" data-server="' . time() . '"><header class="mgg-header"><nav aria-label="' . ($en ? 'Language' : 'Jezik') . '">';
        foreach (['sr' => 'SR', 'en' => 'EN'] as $code => $label) echo '<a href="' . esc_url(MGG_Store::url($row, $code)) . '" hreflang="' . esc_attr($code) . '" lang="' . esc_attr($code) . '" ' . ($code === $lang ? 'aria-current="page"' : '') . '>' . esc_html($label) . '</a>';
        echo '</nav></header><main><section class="mgg-welcome"><div class="mgg-cover">';
        $logo_id = (int) ($s['logo_id'] ?: get_theme_mod('custom_logo', 0));
        $logo = $logo_id ? wp_get_attachment_image_url($logo_id, 'large') : '';
        if ($logo) echo '<img class="mgg-cover-logo" src="' . esc_url($logo) . '" alt="' . esc_attr($s['property']) . '">';
        else echo '<p class="mgg-cover-name">' . esc_html($s['property']) . '</p>';
        echo '</div><p class="mgg-eyebrow">' . esc_html($labels['guide']) . '</p><h1>' . esc_html($en ? 'Welcome.' : 'Dobro došli.') . '</h1><p>' . nl2br(esc_html($text['intro'])) . '</p>';
        if ($p['apartment'] !== '') echo '<p class="mgg-apartment">' . esc_html($labels['apartment']) . ': <strong>' . esc_html($p['apartment']) . '</strong></p>';
        echo '<div class="mgg-times"><span>' . esc_html($labels['checkin']) . ' <strong>' . esc_html($s['checkin']) . '</strong></span><span>' . esc_html($labels['checkout']) . ' <strong>' . esc_html($s['checkout']) . '</strong></span></div></section>';
        echo '<section id="mgg-notices" class="mgg-notices" aria-live="polite" data-url="' . esc_url(add_query_arg('mgg_notices', '1', $url)) . '">' . MGG_Notices::html($apartment_id, $lang) . '</section>';
        MGG_Wellness::card($row, $lang, $p);
        $info = $s['info_' . $lang] ?? '';
        if ($info !== '') echo '<section class="mgg-step mgg-apartment-info"><h2>' . esc_html($en ? 'Apartment information' : 'Informacije o apartmanu') . '</h2><p>' . nl2br(esc_html($info)) . '</p></section>';
        echo '<section class="mgg-step mgg-wifi"><div class="mgg-step-heading"><span class="mgg-number">1</span><h2>' . esc_html($text['wifi_title']) . '</h2></div><p>' . nl2br(esc_html($text['wifi_text'])) . '</p><dl><div><dt>' . esc_html($labels['wifi']) . '</dt><dd>' . esc_html($s['wifi_name']) . '</dd></div>';
        if ($s['wifi_password'] !== '') echo '<div><dt>' . esc_html($labels['password']) . '</dt><dd id="mgg-wifi-password">' . esc_html($s['wifi_password']) . '</dd></div>';
        echo '</dl>';
        if ($s['wifi_password'] !== '') echo '<button class="mgg-copy" type="button" id="mgg-copy-password" data-copied="' . esc_attr($labels['copied']) . '" data-failed="' . esc_attr($labels['copy_fail']) . '">' . esc_html($labels['copy']) . '</button><span class="mgg-copy-feedback" id="mgg-copy-feedback" role="status" aria-live="polite"></span>';
        echo '</section>';
        if ($has_key) echo '<section class="mgg-access"><span class="mgg-key-icon" aria-hidden="true">' . self::arrow() . '</span><div><h2>' . esc_html($en ? 'Your digital key' : 'Vaš digitalni ključ') . '</h2><p>' . esc_html($labels['app']) . '</p><a class="mgg-button" href="' . esc_url($open) . '" rel="noreferrer">' . esc_html($labels['access']) . ' ' . self::arrow() . '</a></div></section>';
        else echo '<section class="mgg-step mgg-key-note"><p>' . esc_html($en ? 'Your personal digital key is available through the separate reservation link sent by your host.' : 'Vaš lični digitalni ključ dostupan je preko posebnog linka rezervacije koji vam šalje domaćin.') . '</p></section>';
        $step = 2;
        foreach (['parking','entrance','door'] as $kind) {
            $body = $text[$kind . '_text'];
            $apartment = $p['apartment'] === '' ? '' : $labels['apartment'] . ': ' . $p['apartment'] . '.';
            $body = str_replace('{apartman}', $apartment, $body);
            echo '<section class="mgg-step mgg-photo-step"><figure><img src="' . esc_url(self::image($s, $kind, $kind === 'door' ? (int) ($p['door_image'] ?? 0) : 0)) . '" alt="' . esc_attr($labels['photo'][$kind]) . '" width="150" height="240" loading="lazy">';
            if ($kind === 'door' && empty($p['door_image']) && empty($s['image_door'])) echo '<figcaption>' . esc_html($labels['example']) . '</figcaption>';
            echo '</figure><div><div class="mgg-step-heading"><span class="mgg-number">' . $step++ . '</span><h2>' . esc_html($text[$kind . '_title']) . '</h2></div><p>' . nl2br(esc_html($body)) . '</p></div></section>';
        }
        echo '<section class="mgg-support"><h2>' . esc_html($labels['help']) . '</h2>';
        if ($phone !== '') echo '<a class="mgg-call" href="tel:' . esc_attr($phone) . '">' . esc_html($s['phone']) . '</a><p>' . esc_html($labels['call']) . '</p>';
        echo '</section><footer class="mgg-footer"><p>' . nl2br(esc_html($text['footer'])) . '</p>';
        if ((int) $row->expires_at > 0) echo '<p>' . esc_html($labels['valid']) . ' <time datetime="' . esc_attr(gmdate('c', (int) $row->expires_at)) . '">' . esc_html(wp_date('d.m.Y. H:i', (int) $row->expires_at, wp_timezone())) . ' (' . esc_html(wp_timezone_string()) . ')</time></p>';
        echo '</footer></main>';
        if ($has_key) echo '<div class="mgg-dock"><a class="mgg-button" href="' . esc_url($open) . '" rel="noreferrer">' . esc_html($labels['access']) . ' ' . self::arrow() . '</a></div>';
        echo '</div><script src="' . esc_url(plugins_url('assets/guest.js', MGG_FILE) . '?ver=' . MGG_VERSION) . '" defer></script><script src="' . esc_url(plugins_url('assets/vendor/flatpickr.min.js', MGG_FILE) . '?ver=4.6.13') . '" defer></script><script src="' . esc_url(plugins_url('assets/date-format.js', MGG_FILE) . '?ver=' . MGG_VERSION) . '" defer></script><script src="' . esc_url(plugins_url('assets/wellness.js', MGG_FILE) . '?ver=' . MGG_VERSION) . '" defer></script></body></html>';
    }
}
