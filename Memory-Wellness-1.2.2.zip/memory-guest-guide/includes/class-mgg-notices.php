<?php
if (!defined('ABSPATH')) exit;

final class MGG_Notices {
    public static function table(): string {
        global $wpdb;
        return $wpdb->prefix . 'memory_guest_notices';
    }

    public static function by_id(int $id): ?object {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table() . ' WHERE id = %d', $id));
    }

    public static function payload(object $row): array {
        $plain = MGG_Store::decrypt($row->payload);
        $p = $plain === null ? null : json_decode($plain, true);
        if (!is_array($p)) throw new RuntimeException('Obavještenje nije moguće otvoriti.');
        return $p;
    }

    public static function active(int $apartment): array {
        global $wpdb;
        $now = time();
        return $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . self::table() . ' WHERE enabled = 1 AND (apartment_id = 0 OR apartment_id = %d) AND (starts_at = 0 OR starts_at <= %d) AND (ends_at = 0 OR ends_at > %d) ORDER BY created_at DESC, id DESC', $apartment, $now, $now)) ?: [];
    }

    public static function html(int $apartment, string $lang): string {
        $items = '';
        foreach (self::active($apartment) as $row) {
            try { $p = self::payload($row); } catch (Throwable $e) { continue; }
            $title = $lang === 'en' && $p['title_en'] !== '' ? $p['title_en'] : $p['title'];
            $body = $lang === 'en' && $p['body_en'] !== '' ? $p['body_en'] : $p['body'];
            $items .= '<article class="mgg-notice"><h3>' . esc_html($title) . '</h3><p>' . nl2br(esc_html($body)) . '</p>';
            if ($p['url'] !== '') $items .= '<a href="' . esc_url($p['url'], ['http','https']) . '" target="_blank" rel="noopener noreferrer">' . ($lang === 'en' ? 'Learn more' : 'Saznaj više') . ' <span aria-hidden="true">&rarr;</span></a>';
            $items .= '</article>';
        }
        return $items === '' ? '' : '<h2>' . ($lang === 'en' ? 'Guest notices' : 'Obavještenja za goste') . '</h2>' . $items;
    }

    public static function listing(): void {
        MGG_Admin::guard();
        if (isset($_GET['new']) || isset($_GET['id'])) { self::editor(absint($_GET['id'] ?? 0)); return; }
        global $wpdb;
        $page = max(1, absint($_GET['paged'] ?? 1));
        $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . self::table() . ' ORDER BY id DESC LIMIT 20 OFFSET %d', ($page - 1) * 20));
        $total = (int) $wpdb->get_var('SELECT COUNT(*) FROM ' . self::table());
        echo '<div class="wrap mgg-admin"><h1>Obavještenja <a class="page-title-action" href="' . esc_url(MGG_Admin::url('-notices', ['new' => 1])) . '">Novo obavještenje</a></h1><p>Obavještenja se prikazuju u vodiču preko postojećih linkova i QR kodova, prema apartmanu i periodu važenja.</p>';
        if (isset($_GET['saved'])) echo '<div class="notice notice-success"><p>Promjena je sačuvana.</p></div>';
        echo '<table class="widefat striped"><thead><tr><th>Naslov</th><th>Apartman</th><th>Status i period</th><th>Radnje</th></tr></thead><tbody>';
        foreach ($rows as $row) {
            try { $p = self::payload($row); } catch (Throwable $e) { continue; }
            $now = time();
            $status = !$row->enabled ? 'Neaktivno' : ($row->starts_at > $now ? 'Zakazano' : ($row->ends_at && $row->ends_at <= $now ? 'Isteklo' : 'Aktivno'));
            $target = $row->apartment_id ? MGG_Apartments::label((int) $row->apartment_id) : 'Svi apartmani';
            echo '<tr><td><strong>' . esc_html($p['title']) . '</strong></td><td>' . esc_html($target ?: 'Apartman više nije objavljen') . '</td><td>' . esc_html($status) . '<br>' . esc_html($row->starts_at ? MGG_Admin::date((int) $row->starts_at) : 'Odmah') . ' — ' . esc_html($row->ends_at ? MGG_Admin::date((int) $row->ends_at) : 'Bez datuma završetka') . '</td><td><a class="button" href="' . esc_url(MGG_Admin::url('-notices', ['id' => $row->id])) . '">Uredi</a> ';
            foreach (['toggle' => $row->enabled ? 'Deaktiviraj' : 'Aktiviraj', 'delete' => 'Obriši'] as $verb => $label) {
                echo '<form class="mgg-inline" method="post" action="' . esc_url(admin_url('admin-post.php')) . '" ' . ($verb === 'delete' ? 'data-mgg-confirm="Obrisati ovo obavještenje?"' : '') . '>';
                wp_nonce_field('mgg_notice_' . $verb . '_' . $row->id);
                echo '<input type="hidden" name="action" value="mgg_notice_action"><input type="hidden" name="verb" value="' . esc_attr($verb) . '"><input type="hidden" name="id" value="' . (int) $row->id . '"><button class="button" type="submit">' . esc_html($label) . '</button></form>';
            }
            echo '</td></tr>';
        }
        if (!$rows) echo '<tr><td colspan="4">Još nema obavještenja.</td></tr>';
        echo '</tbody></table>';
        if ($total > 20) echo '<div class="tablenav-pages">' . wp_kses_post(paginate_links(['base' => add_query_arg('paged', '%#%', MGG_Admin::url('-notices')), 'format' => '', 'current' => $page, 'total' => (int) ceil($total / 20)])) . '</div>';
        echo '<p>Vrijeme: ' . esc_html(wp_timezone_string()) . '. Datum završetka označava trenutak kada se obavještenje prestaje prikazivati.</p></div>';
    }

    private static function editor(int $id): void {
        try {
            $row = $id ? self::by_id($id) : null;
            if ($id && !$row) throw new InvalidArgumentException('Obavještenje ne postoji.');
            $p = $row ? self::payload($row) : ['title' => '', 'body' => '', 'title_en' => '', 'body_en' => '', 'url' => ''];
        } catch (Throwable $e) { wp_die(esc_html($e->getMessage())); }
        echo '<div class="wrap mgg-admin"><h1>' . ($row ? 'Uredi obavještenje' : 'Novo obavještenje') . '</h1><form class="mgg-panel" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('mgg_save_notice');
        echo '<input type="hidden" name="action" value="mgg_save_notice"><input type="hidden" name="id" value="' . $id . '"><table class="form-table">';
        MGG_Admin::input('title', 'Naslov', $p['title'], 'text', '', true);
        echo '<tr><th><label for="mgg-body">Tekst</label></th><td><textarea class="large-text" rows="5" name="body" id="mgg-body" required>' . esc_textarea($p['body']) . '</textarea></td></tr>';
        MGG_Admin::input('url', 'URL link', $p['url'], 'url', 'Opciono, puna http/https adresa.');
        echo '<tr><th><label for="mgg-apartment_id">Namijenjeno apartmanu</label></th><td>';
        MGG_Apartments::select('apartment_id', (int) ($row->apartment_id ?? 0));
        echo '</td></tr><tr><th>Status</th><td><label><input type="checkbox" name="enabled" value="1" ' . checked(!$row || $row->enabled, true, false) . '> Aktivno</label></td></tr>';
        foreach (['starts_at' => 'Prikazuj od', 'ends_at' => 'Prikazuj do'] as $key => $label) MGG_Admin::input($key, $label, $row && $row->$key ? wp_date('Y-m-d\TH:i', (int) $row->$key, wp_timezone()) : '', 'datetime-local', 'Prazno: ' . ($key === 'starts_at' ? 'prikazuje se odmah.' : 'bez vremenskog ograničenja.'));
        MGG_Admin::input('title_en', 'Naslov na engleskom', $p['title_en'], 'text', 'Opciono. Bez prevoda koristi se osnovni tekst.');
        echo '<tr><th><label for="mgg-body_en">Tekst na engleskom</label></th><td><textarea class="large-text" rows="5" name="body_en" id="mgg-body_en">' . esc_textarea($p['body_en']) . '</textarea></td></tr></table>';
        submit_button('Sačuvaj obavještenje');
        echo '</form></div>';
    }

    public static function parse_date($raw): int {
        $raw = MGG_Admin::clean($raw, 30);
        if ($raw === '') return 0;
        $date = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', $raw, wp_timezone());
        if (!$date || $date->format('Y-m-d\TH:i') !== $raw) throw new InvalidArgumentException('Datum nije ispravan.');
        return $date->getTimestamp();
    }

    public static function save(): void {
        MGG_Admin::guard(); check_admin_referer('mgg_save_notice');
        try {
            $id = absint($_POST['id'] ?? 0);
            if ($id && !self::by_id($id)) throw new InvalidArgumentException('Obavještenje ne postoji.');
            $target = absint($_POST['apartment_id'] ?? 0);
            if ($target && !MGG_Apartments::valid($target)) throw new InvalidArgumentException('Izaberite objavljen apartman.');
            $p = [];
            foreach (['title','body','title_en','body_en'] as $key) $p[$key] = MGG_Admin::clean($_POST[$key] ?? '', str_starts_with($key, 'title') ? 240 : 12000, !str_starts_with($key, 'title'));
            if ($p['title'] === '' || $p['body'] === '') throw new InvalidArgumentException('Unesite naslov i tekst obavještenja.');
            $url = MGG_Admin::clean($_POST['url'] ?? '', 4096);
            if ($url !== '') {
                $parsed = wp_parse_url($url);
                if (!$parsed || empty($parsed['host']) || !in_array(strtolower($parsed['scheme'] ?? ''), ['http','https'], true) || isset($parsed['user']) || isset($parsed['pass'])) throw new InvalidArgumentException('Unesite punu http/https URL adresu.');
            }
            $p['url'] = esc_url_raw($url, ['http','https']);
            $start = self::parse_date($_POST['starts_at'] ?? ''); $end = self::parse_date($_POST['ends_at'] ?? '');
            if ($start && $end && $end <= $start) throw new InvalidArgumentException('Završetak mora biti poslije početka.');
            $data = ['apartment_id' => $target, 'enabled' => empty($_POST['enabled']) ? 0 : 1, 'starts_at' => $start, 'ends_at' => $end, 'payload' => MGG_Store::encrypt(wp_json_encode($p, JSON_UNESCAPED_UNICODE)), 'updated_at' => time()];
            global $wpdb;
            if ($id) $ok = $wpdb->update(self::table(), $data, ['id' => $id], ['%d','%d','%d','%d','%s','%d'], ['%d']);
            else { $data['created_at'] = time(); $ok = $wpdb->insert(self::table(), $data, ['%d','%d','%d','%d','%s','%d','%d']); }
            if ($ok === false) throw new RuntimeException('Čuvanje obavještenja nije uspjelo.');
        } catch (Throwable $e) { wp_die(esc_html($e->getMessage()), '', ['response' => 400, 'back_link' => true]); }
        wp_safe_redirect(MGG_Admin::url('-notices', ['saved' => 1])); exit;
    }

    public static function action(): void {
        MGG_Admin::guard(); $id = absint($_POST['id'] ?? 0); $verb = sanitize_key($_POST['verb'] ?? '');
        if (!in_array($verb, ['toggle','delete'], true)) wp_die('Nepoznata radnja.', '', ['response' => 400]);
        check_admin_referer('mgg_notice_' . $verb . '_' . $id);
        global $wpdb;
        if ($verb === 'delete') $wpdb->delete(self::table(), ['id' => $id], ['%d']);
        else $wpdb->query($wpdb->prepare('UPDATE ' . self::table() . ' SET enabled = 1 - enabled, updated_at = %d WHERE id = %d', time(), $id));
        wp_safe_redirect(MGG_Admin::url('-notices', ['saved' => 1])); exit;
    }
}
