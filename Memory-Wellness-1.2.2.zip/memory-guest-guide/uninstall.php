<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;
// Preserve reservations unless the site owner explicitly opted in to deletion.
if (defined('MGG_DELETE_DATA') && MGG_DELETE_DATA === true) {
    global $wpdb;
    $wpdb->query('DROP TABLE IF EXISTS ' . $wpdb->prefix . 'memory_guest_links');
    $wpdb->query('DROP TABLE IF EXISTS ' . $wpdb->prefix . 'memory_guest_notices');
    foreach (['bookings','claims','state'] as $part) $wpdb->query('DROP TABLE IF EXISTS ' . $wpdb->prefix . 'memory_wellness_' . $part);
    delete_option('mgg_wellness_db_version');
    delete_option('mgg_settings');
    delete_option('mgg_db_version');
    delete_post_meta_by_key('_mgg_guide_config');
    delete_post_meta_by_key('_mgg_link_id');
    foreach (get_posts(['post_type' => 'mgg_apartment', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids']) as $id) wp_delete_post($id, true);
}
