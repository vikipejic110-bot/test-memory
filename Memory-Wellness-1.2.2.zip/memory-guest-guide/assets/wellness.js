(() => {
  'use strict';
  const root = document.getElementById('mgg-wellness');
  if (!root) return;
  const labels = JSON.parse(root.dataset.labels);
  const details = root.querySelector('details');
  const form = root.querySelector('form');
  const date = form.elements.wellness_day, start = form.elements.wellness_start, end = form.elements.wellness_end;
  const slots = root.querySelector('.mgg-wellness-slots');
  const feedback = root.querySelector('.mgg-wellness-feedback');
  const mine = root.querySelector('.mgg-wellness-mine');
  const submit = form.querySelector('button[type=submit]');
  let schedule = null, sending = false, loading = false, generation = 0, controller;
  const requestKey = () => Array.from(crypto.getRandomValues(new Uint8Array(16)), n => n.toString(16).padStart(2, '0')).join('');
  let key = requestKey();
  const time = hour => String(hour).padStart(2, '0') + ':00';
  function option(select, value, text) {
    const el = document.createElement('option'); el.value = value; el.textContent = text; select.append(el);
  }
  function updateEnd(preferred = '') {
    const previous = preferred || end.value;
    end.replaceChildren(); option(end, '', '—');
    if (start.value !== '') {
      const available = new Set((schedule?.slots || []).filter(s => s.status === 'free').map(s => s.hour));
      for (let hour = Number(start.value); available.has(hour); hour++) option(end, hour + 1, time(hour + 1));
      if ([...end.options].some(o => o.value === String(previous))) end.value = previous;
      else if (end.options.length > 1) end.selectedIndex = 1;
    }
    submit.disabled = sending || start.value === '' || end.value === '' || !schedule?.enabled;
  }
  function paint(data) {
    schedule = data;
    root.dataset.day = data.day;
    date.min = data.min; date.max = data.max;
    window.MGGWellnessDates?.bounds(date, data.min, data.max);
    const selected = start.value, previousEnd = end.value;
    slots.replaceChildren(); start.replaceChildren(); option(start, '', '—');
    for (const slot of data.slots) {
      const button = document.createElement('button'); button.type = 'button';
      button.className = 'mgg-wellness-slot ' + slot.status;
      const label = document.createElement('strong'); label.textContent = slot.label;
      const status = document.createElement('span'); status.textContent = labels.statuses[slot.status];
      button.append(label, status); button.disabled = slot.status !== 'free' || !data.enabled;
      button.addEventListener('click', () => { start.value = slot.hour; updateEnd(); key = requestKey(); });
      slots.append(button);
      if (slot.status === 'free' && data.enabled) option(start, slot.hour, time(slot.hour));
    }
    if ([...start.options].some(o => o.value === selected)) start.value = selected;
    updateEnd(previousEnd);
    if (!data.enabled || !data.slots.length) {
      const p = document.createElement('p'); p.textContent = data.enabled ? labels.empty : labels.closed; slots.append(p);
    }
    mine.replaceChildren();
    if (data.mine.length) {
      const h = document.createElement('h3'); h.textContent = labels.mine; mine.append(h);
      for (const item of data.mine) {
        const p = document.createElement('p'); p.className = 'mgg-wellness-own ' + item.status;
        p.textContent = time(Number(item.start_hour)) + '–' + time(Number(item.end_hour)) + ' · ' + labels.statuses[item.status];
        mine.append(p);
      }
    }
  }
  async function load(force = false) {
    if (sending || !date.value || (!force && loading)) return;
    controller?.abort(); controller = new AbortController();
    const current = ++generation; loading = true;
    try {
      const url = new URL(root.dataset.slots); url.searchParams.set('mgg_day', date.value);
      const response = await fetch(url, {cache: 'no-store', credentials: 'same-origin', signal: controller.signal});
      if (response.status === 410 || response.status === 404) { feedback.textContent = labels.expired; submit.disabled = true; return; }
      const body = await response.json();
      if (!response.ok || !body.ok) throw new Error(body.message || labels.error);
      if (current === generation) paint(body.data);
    } catch (error) {
      if (error.name !== 'AbortError' && current === generation) { feedback.textContent = error.message || labels.error; submit.disabled = true; }
    } finally { if (current === generation) loading = false; }
  }
  date.addEventListener('change', () => { key = requestKey(); feedback.textContent = labels.load; start.replaceChildren(); end.replaceChildren(); submit.disabled = true; load(true).then(() => { if (feedback.textContent === labels.load) feedback.textContent = ''; }); });
  start.addEventListener('change', () => { key = requestKey(); updateEnd(); });
  end.addEventListener('change', () => { key = requestKey(); updateEnd(); });
  form.elements.wellness_name.addEventListener('input', () => { key = requestKey(); });
  form.elements.wellness_note.addEventListener('input', () => { key = requestKey(); });
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (sending || !form.reportValidity()) return;
    if (start.value === '' || end.value === '') { feedback.textContent = labels.choose; return; }
    sending = true; controller?.abort(); ++generation; loading = false;
    submit.disabled = true; submit.textContent = labels.sending;
    const body = new URLSearchParams(new FormData(form)); body.set('request_id', key);
    try {
      const response = await fetch(root.dataset.request, {method: 'POST', body, cache: 'no-store', credentials: 'same-origin'});
      if (response.status === 410) throw new Error(labels.expired);
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.message || labels.error);
      key = requestKey();
      feedback.textContent = result.data.status === 'pending' ? labels.sent : (labels.statuses[result.data.status] || labels.sent);
      paint(result.data.schedule);
    } catch (error) {
      feedback.textContent = error.message || labels.error;
    } finally {
      sending = false; submit.textContent = labels.send; updateEnd(); await load(true);
    }
  });
  details.addEventListener('toggle', () => { if (details.open) load(true); });
  setInterval(() => { if (details.open && !document.hidden) load(); }, 15000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden && details.open) load(true); });
})();
