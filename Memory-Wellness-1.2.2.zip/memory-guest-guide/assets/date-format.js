(() => {
  'use strict';
  if (typeof window.flatpickr !== 'function') return;
  const english = document.documentElement.lang.toLowerCase().startsWith('en');
  const latin = {
    firstDayOfWeek: 1,
    weekdays: {
      shorthand: ['Ned', 'Pon', 'Uto', 'Sri', 'Čet', 'Pet', 'Sub'],
      longhand: ['Nedjelja', 'Ponedjeljak', 'Utorak', 'Srijeda', 'Četvrtak', 'Petak', 'Subota']
    },
    months: {
      shorthand: ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Avg', 'Sep', 'Okt', 'Nov', 'Dec'],
      longhand: ['Januar', 'Februar', 'Mart', 'April', 'Maj', 'Jun', 'Jul', 'Avgust', 'Septembar', 'Oktobar', 'Novembar', 'Decembar']
    },
    ordinal: () => '.', rangeSeparator: ' — ', weekAbbreviation: 'Sed.',
    scrollTitle: 'Pomjerite za promjenu', toggleTitle: 'Promijenite prikaz',
    yearAriaLabel: 'Godina', monthAriaLabel: 'Mjesec', time_24hr: true
  };

  function start() {
    document.querySelectorAll('#mgg-wellness input[type="date"], .mgg-wellness-admin input[type="date"]').forEach(input => {
      if (input._flatpickr) return;
      window.flatpickr(input, {
        dateFormat: 'Y-m-d',
        altInput: true,
        altFormat: 'j.n.Y',
        altInputClass: 'mgg-date-display',
        ariaDateFormat: 'j.n.Y',
        defaultDate: input.value || undefined,
        minDate: input.min || undefined,
        maxDate: input.max || undefined,
        disableMobile: true,
        allowInput: false,
        locale: english ? {firstDayOfWeek: 1} : latin,
        onReady: (_, __, picker) => {
          picker.calendarContainer.classList.add('mgg-date-calendar');
        }
      });
    });
  }

  // Keep server-provided ISO bounds while the visible field stays day.month.year.
  window.MGGWellnessDates = {
    bounds(input, min, max) {
      input.min = min; input.max = max;
      const picker = input._flatpickr;
      if (!picker) return;
      const from = picker.config.minDate ? picker.formatDate(picker.config.minDate, 'Y-m-d') : '';
      const until = picker.config.maxDate ? picker.formatDate(picker.config.maxDate, 'Y-m-d') : '';
      if (from !== min || until !== max) picker.set({minDate: min, maxDate: max});
    }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once: true});
  else start();
})();
