(() => {
  'use strict';
  const root = document.getElementById('mgg-guide');
  if (!root) return;
  const elapsedStart = performance.now();
  const remaining = (Number(root.dataset.expires) - Number(root.dataset.server)) * 1000;
  function expiry() {
    if (Number(root.dataset.expires) > 0 && performance.now() - elapsedStart >= remaining) location.reload();
  }
  setInterval(expiry, 10000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) expiry(); });
  const notices = document.getElementById('mgg-notices');
  let loading = false;
  async function refreshNotices() {
    if (!notices || loading || document.hidden) return;
    loading = true;
    try {
      const response = await fetch(notices.dataset.url, {cache:'no-store', credentials:'same-origin'});
      if (response.status === 410 || response.status === 404) { location.reload(); return; }
      if (!response.ok) return;
      const data = await response.json();
      if (typeof data.html === 'string' && notices.innerHTML !== data.html) notices.innerHTML = data.html;
    } catch (_) {} finally { loading = false; }
  }
  setInterval(refreshNotices, 20000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshNotices(); });
  document.getElementById('mgg-copy-password')?.addEventListener('click', async event => {
    const button = event.currentTarget;
    const text = document.getElementById('mgg-wifi-password').textContent;
    const status = document.getElementById('mgg-copy-feedback');
    try {
      await navigator.clipboard.writeText(text);
      status.textContent = button.dataset.copied;
    } catch (_) {
      const range = document.createRange();
      range.selectNodeContents(document.getElementById('mgg-wifi-password'));
      const selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      status.textContent = button.dataset.failed;
    }
  });
})();
