(() => {
  'use strict';
  document.addEventListener('click', async event => {
    const copy = event.target.closest('[data-mgg-copy]');
    if (copy) {
      const status = document.getElementById('mgg-copy-status');
      try {
        if (navigator.clipboard && window.isSecureContext) {
          await navigator.clipboard.writeText(copy.dataset.mggCopy);
        } else {
          const area = document.createElement('textarea');
          area.value = copy.dataset.mggCopy;
          area.className = 'mgg-copy-fallback';
          document.body.append(area);
          area.select();
          const ok = document.execCommand('copy');
          area.remove();
          copy.focus();
          if (!ok) throw new Error('Clipboard unavailable');
        }
        if (status) status.textContent = 'Kopirano. Zalijepite u poruku gostu.';
        const previous = copy.textContent;
        copy.textContent = 'Kopirano ✓';
        setTimeout(() => { copy.textContent = previous; }, 1800);
      } catch (_) {
        if (status) status.textContent = 'Kopiranje nije dostupno. Označite i kopirajte link iz polja.';
      }
    }
    const pick = event.target.closest('.mgg-pick-image');
    if (pick && window.wp?.media) {
      const holder = pick.closest('.mgg-media');
      const frame = wp.media({title:'Izaberite fotografiju', library:{type:'image'}, multiple:false, button:{text:'Koristi fotografiju'}});
      frame.on('select', () => {
        const item = frame.state().get('selection').first().toJSON();
        holder.querySelector('input').value = item.id;
        const image = holder.querySelector('img');
        image.src = item.sizes?.thumbnail?.url || item.url;
        image.hidden = false;
      });
      frame.open();
    }
    const remove = event.target.closest('.mgg-remove-image');
    if (remove) {
      const holder = remove.closest('.mgg-media');
      holder.querySelector('input').value = '0';
      const image = holder.querySelector('img');
      image.removeAttribute('src');
      image.hidden = true;
    }
    const qrButton = event.target.closest('[data-mgg-qr]');
    if (qrButton && typeof window.qrcode === 'function') {
      const qr = window.qrcode(0, 'M');
      qr.addData(qrButton.dataset.mggQr, 'Byte');
      qr.make();
      const dialog = document.createElement('dialog');
      dialog.className = 'mgg-qr-dialog';
      const heading = document.createElement('h2'); heading.textContent = 'QR kod vodiča';
      const canvas = document.createElement('canvas');
      const count = qr.getModuleCount(), scale = 7, border = 4;
      canvas.width = canvas.height = (count + border * 2) * scale;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.fillStyle = '#000000';
      for (let y=0;y<count;y++) for(let x=0;x<count;x++) if(qr.isDark(y,x)) ctx.fillRect((x+border)*scale,(y+border)*scale,scale,scale);
      const caption = document.createElement('p');caption.textContent = 'QR otvara isti link. Nije potrebno ponovno slanje nakon izmjene uputstva ili obavještenja.';
      const download = document.createElement('a'); download.className='button button-primary';download.textContent='Preuzmi PNG';download.download='memory-vodic-qr.png';download.href=canvas.toDataURL('image/png');
      const close = document.createElement('button');close.className='button';close.type='button';close.textContent='Zatvori';close.addEventListener('click',()=>dialog.close());
      dialog.append(heading,canvas,caption,download,document.createTextNode(' '),close);
      document.body.append(dialog);dialog.addEventListener('close',()=>{dialog.remove();qrButton.focus();},{once:true});dialog.showModal();close.focus();
    }
  });
  document.addEventListener('submit', event => {
    const message = event.target.dataset.mggConfirm;
    if (message && !window.confirm(message)) event.preventDefault();
  });
})();
