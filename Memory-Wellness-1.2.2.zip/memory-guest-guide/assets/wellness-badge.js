(() => {
  'use strict';
  const config = window.mggWellnessBadge;
  if (!config) return;
  const link = document.querySelector('#adminmenu a[href*="page=memory-guest-guide-wellness"]');
  if (!link) return;
  let loading = false, expired = false;

  function paint(count) {
    if (!Number.isSafeInteger(count) || count < 0) return;
    let badge = link.querySelector('.mgg-wellness-count');
    if (!count) badge?.remove();
    else {
      if (!badge) {
        badge = document.createElement('span');
        badge.setAttribute('aria-live', 'polite');
        const number = document.createElement('span'); number.className = 'plugin-count';
        badge.append(number); link.append(document.createTextNode(' '), badge);
      }
      badge.className = 'update-plugins count-' + count + ' mgg-wellness-count';
      badge.setAttribute('aria-label', config.label + count);
      badge.querySelector('.plugin-count').textContent = count;
    }
    // Clicking the notification takes Milan directly to all pending requests.
    const url = new URL(link.href);
    if (count) url.searchParams.set('pending', '1');
    else url.searchParams.delete('pending');
    link.href = url.href;
  }

  async function refresh() {
    if (loading || expired || document.hidden) return;
    loading = true;
    try {
      const body = new URLSearchParams({action: 'mgg_wellness_count', nonce: config.nonce});
      const response = await fetch(config.url, {method: 'POST', body, credentials: 'same-origin', cache: 'no-store'});
      if (response.status === 403) { expired = true; return; }
      if (!response.ok) return;
      const result = await response.json();
      if (result.success) paint(result.data.count);
    } catch (_) {
      // Preserve the last known count if the connection is interrupted.
    } finally { loading = false; }
  }

  const initial = Number(link.querySelector('.plugin-count')?.textContent || 0);
  paint(initial);
  setInterval(refresh, 15000);
  window.addEventListener('focus', refresh);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
})();
